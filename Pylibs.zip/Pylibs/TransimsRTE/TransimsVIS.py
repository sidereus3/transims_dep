
# The following variables are automatically updated by SVN - do not modify!
RevSVN = '$Revision: 97 $'
DateSVN = '$Date: 2010-07-15 15:06:15 -0500 (Thu, 15 Jul 2010) $'
AuthorSVN = '$Author: michaelhope $'

RTE_Revision = int(RevSVN[11:26].strip(' $'))
RTE_Date = DateSVN.split('(')[1].split(')')[0]
RTE_Author = AuthorSVN[9:].strip(' $')

def GetVersion ():
	return RTE_Revision,RTE_Date,RTE_Author

#======== Don't modify any of the code above this line! ========#

__all__ = ( 'CompressSnapshot',
			'GetVersion'
			)

import struct

out_line=struct.Struct("=iiicccc")
snap_line=struct.Struct("=i16s10xf4xb4xhdd8xh")

def write_timestep(key_vehs,key,outfile):
	rmvehs=[]
	for (k,v) in key_vehs.iteritems():
		if v[0]:
			outfile.write(out_line.pack(k,v[1],v[2],v[4],v[5],v[6],v[7]))
		if not v[8]:
			rmvehs.append(k)
			outfile.write(out_line.pack(k,v[1],v[2],v[4],v[5],chr(0),v[7]))
	for entry in rmvehs:
		key_vehs.pop(entry)

def CompressSnapshot (input_file, output_file, index_file):

	file=open(input_file,"rb")
	outfile=open(output_file,"wb",9)
	index=open(index_file,"w")

	key_vehs=dict()
	first=True
	interval=0
	prev_tim=0
	
	while True:
		yar=file.read(71)
		if yar=="":
			index.write(str(step)+'\t'+str(outfile.tell())+'\n')
			write_timestep(key_vehs,step%60==0,outfile)
			index.write(str(step+interval)+'\t'+str(outfile.tell())+'\n')
			index.write(str(step+interval*2)+'\t'+str(outfile.tell())+'\n')
			break
		line=snap_line.unpack(yar)
		veh=line[0]
		

		tim=(line[1].split('\0')[0]).split(':')
		if len(tim)==1:
			tim=int(tim[0])
		elif len(tim)==2:
			tim=int(tim[0])*60*60+int(tim[1])*60
		elif len(tim)==3:
			tim=int(tim[0])*60*60+int(tim[1])*60+int(tim[2])
		
		if interval==0 and prev_tim!=0: interval=tim-prev_tim			
		elif prev_tim==0: prev_tim=tim
		
		if first:
			step=tim
			first=False
		if tim!=step:
			index.write(str(step)+'\t'+str(outfile.tell())+'\n')
			write_timestep(key_vehs,step%60==0,outfile)
			step=tim
			if step%60==0:
				print step
				key_vehs.clear()
			else:
				for att in key_vehs.itervalues():
					att[0]=False
					att[8]=False
		
		speed=chr(max(int(line[2]),0))
		veh_type=chr(line[3])
		try:
			passengers=chr(line[4]+1)
		except:
			passengers=chr(254)

		x=line[5]
		x=int(x*10)
		y=line[6]
		y=int(y*10)

		bear=chr(int(round(float(line[7])*(256./360.),0)))
		
		attributes=[True,x,y,[],bear,speed,passengers,veh_type,True]
		if veh not in key_vehs:
			key_vehs[veh]=attributes
			continue
		key_vehs[veh][8]=True
		if(key_vehs[veh][1]==attributes[1] and key_vehs[veh][2]==attributes[2] and key_vehs[veh][5]==attributes[5] and key_vehs[veh][6]==attributes[6]):
			key_vehs[veh][0]=False
			continue
		key_vehs[veh]=attributes
		
	outfile.close()
