
import sys
import platform

# check whether the Python version is acceptable. Release candidate versions are marked with an 'rcX', split that off before comparing numbers.
V = platform.python_version().split('r')
V = V[0].split('.')
if int(V[0]) != 2 or int(V[1]) < 6:
	print 'This script requires Python 2.6 or higher. Python 3.x does not provide all the required modules at this time.'
	sys.exit(0)

# The following variables are automatically updated by SVN - do not modify!
RevSVN = '$Revision: 105 $'
DateSVN = '$Date: 2010-08-18 17:51:08 -0500 (Wed, 18 Aug 2010) $'
AuthorSVN = '$Author: hubertley $'

RTE_Version = '0.9.9'
RTE_Revision = int(RevSVN[11:26].strip(' $'))
RTE_Date = DateSVN.split('(')[1].split(')')[0]
RTE_Author = AuthorSVN[9:].strip(' $')

import Utilities
(R,D,A) = Utilities.GetVersion()
if R > RTE_Revision:
	RTE_Revision = R
	RTE_Date = D
	RTE_Author = A

import TransimsVIS
(R,D,A) = Utilities.GetVersion()
if R > RTE_Revision:
	RTE_Revision = R
	RTE_Date = D
	RTE_Author = A

#======== Don't modify any of the code above this line! ========#

# the public API for TransimsRTE contains the following objects only. All
# other objects are internal functions and variables that should not be made
# available to the user.
__all__ = ( 'var',
			'GlobalKeys',
			'Event',
			'CreateDirectory',
			'ReplaceFilesWithPlaceholders',
			'CompressSnapshot',
			'GetNumberOfCPUs',
			'ExpandTemplate',
			'ControlKeys'
			)

import re
import os
import sys
import glob
import copy
import time
import copy
import shlex
import types
import Queue
import pickle
import threading
import traceback
import subprocess
from collections import deque

from Utilities import MakeRelativePath,MakeAbsolutePath,GetPartitionFilename,LoadCacheFromFile
import TransimsVIS

#
# Lookup tables
#	NOTE: this lookup table is an experimental feature that is not
# advertised to the users. It works for only one key, and the methodology
# would need to change significantly to make this work universally.
#=====================================================================
#
FacilityType = {}
FacilityType['FREEWAY']    = 1
FacilityType['EXPRESSWAY'] = 2
FacilityType['PRINCIPAL']  = 3
FacilityType['MAJOR']      = 4
FacilityType['MINOR']      = 5
FacilityType['COLLECTOR']  = 6
FacilityType['LOCAL']      = 7
FacilityType['FRONTAGE']   = 8
FacilityType['RAMP']       = 9
FacilityType['BRIDGE']     = 10
FacilityType['WALKWAY']    = 11
FacilityType['BIKEWAY']    = 12
FacilityType['BUSWAY']     = 13
FacilityType['LIGHTRAIL']  = 14
FacilityType['HEAVYRAIL']  = 15
FacilityType['FERRY']      = 16
FacilityType['EXTERNAL']   = 17




#=========================================================================================================================
def CompressSnapshot (input_file, output_file, index_file):
	"""
	Experimental function to create compressed snapshot files for
	visualization.

	@note: Needs additional documentation!
	"""
	input_file = ExpandTemplate(input_file)
	output_file = ExpandTemplate(output_file)
	index_file = ExpandTemplate(index_file)
	TransimsVIS.CompressSnapshot (input_file, output_file, index_file)




#=========================================================================================================================
def GetNumberOfCPUs():
	"""
	Detects the number of CPUs on the system. Local system only, meaning that
	it is not possible to detect CPUs on participating nodes in a cluster
	environment.

	@note: Needs additional documentation!
	"""
	# Linux, Unix and MacOS:
	if hasattr(os, "sysconf"):
		if os.sysconf_names.has_key("SC_NPROCESSORS_ONLN"):
			# Linux & Unix:
			ncpus = os.sysconf("SC_NPROCESSORS_ONLN")
			if isinstance(ncpus, int) and ncpus > 0:
				return ncpus
		else:
			# OSX:
			return int(os.popen2("sysctl -n hw.ncpu")[1].read())
	# Windows:
	if os.environ.has_key("NUMBER_OF_PROCESSORS"):
		ncpus = int(os.environ["NUMBER_OF_PROCESSORS"])
		if ncpus > 0:
			return ncpus
	return 1 # Default




#=========================================================================================================================
def Event (Message):
	"""
	The RTE function "Event" can be used to place a visual
	separator into the log file and the tool sequence window, e.g.
	to indicate that a certain iteration is starting. The function does
	not have any programmatic effect at all. The single argument to
	the function is a string, e.g. Event("Iteration 13"). The string will
	be filtered using the currently defined template variables in "var".

	@note: Needs additional documentation!
	"""

	global EmbedGuiHints
	# replace all template strings with the current value
	Message = ExpandTemplate(Message)

	# pass the message to the GUI through stdout if requested
	if EmbedGuiHints:
		Lock.acquire()
		print '@GUI@ EVT 0 0',Message
		Lock.release()

	# write the message into the log on stdout as a visual separator
	Progress ('==========='+'='*len(str(Message))+'===========')
	Progress ('========== '+str(Message)+' ==========')
	Progress ('==========='+'='*len(str(Message))+'===========')

	return




#=========================================================================================================================
def Filter (Partition, Line, Type='ALL'):
	"""
	Instead of displaying every line of output from a module while it is
	executing, this function filters the output so that only a few major
	progress indicators are shown to the user. The function is only used
	internally and should never be called by the user. The function makes use
	of two global variables "TimerArray" and "FilterArray" to decide when
	to write a line as a message to the log on standard output. The algorithm
	is both time-based but ensures that lines meeting certain criteria are
	always shown.
	"""

	# turn the Type variable into a string in case it isn't already
	Type = str (Type)

	# there are four allowed values for the Type, and an error is generated if the value is illegal. 'PROGRESS'
	# is the most common type, and will suppress most of the output from the TRANSIMS tool. The line is checked
	# for a message indicating that progress is going to be shown. If yes, the first progress line is always
	# shown, and afterwards a minimum amount of time has to be elapsed before another one is shown. This works
	# only when the '-B' option is specified when starting the TRANSIMS module. The filter also prepends the
	# partition number for lines being displayed.
	if Type == 'PROGRESS':
		if Line.find ('- Record') >= 0 or Line.find ('- Plan') >= 0:
			FilterArray[Partition] = Line[:Line.find ('-')-1].strip()
			TimerArray[Partition] = time.time() - var.FILTER_INTERVAL
		elif Line.find ('Record:') >= 0:
			if time.time() >= TimerArray[Partition] + var.FILTER_INTERVAL:
				if Partition == None:
					Progress (FilterArray[Partition] + Line[8:], FromThread=True)
				else:
					Progress ('P-' + str (Partition) + ':' + ' '*(4-len(str(Partition))) + FilterArray[Partition] + Line[8:], FromThread=True)
				TimerArray[Partition] = time.time()

	# The 'ALL' method simply passes all content through, while 'DOTS' writes a dot
	# for each line encountered.
	elif Type == 'ALL':
		if Partition == None:
			Progress (Line.strip(), FromThread=True)
		else:
			Progress ('P-' + str (Partition) + ':' + ' '*(4-len(str(Partition))) + Line.strip(), FromThread=True)

	# 'DOTS' does not work with RTE and should probably be removed. But it is
	# useful during normal DOS or Linux window command line execution for visual feedback.
	elif Type == 'DOTS':
		Progress (FromThread=True)

	# "NONE' suppresses output completely, and other values will cause an error message
	elif Type != 'NONE':
		Error (100104,'Illegal value for SHOW_MODULE_OUTPUT: "' + Type + '"')

	return

# These are the global variables used by Filter
TimerArray = {}
FilterArray = {}




#=========================================================================================================================
def RunExecutableInPipe (PassThroughData, Executable, NewControlFile, Thread, Node=None, Core=0, Partition=None, Execute=True):
	"""
	This function is called by each thread (one for each partition) to prepare
	the module for execution, open it in a pipe, watch over its output line by
	line, and finally gather return codes and other information about the execution.
	The function is invoked simultaneously for all partitions, so special care
	needs to be taken to ensure that data is thread safe. It is also used for the
	execution of serial tools. This is an internal function that should never be
	called by the user.
	"""

	# return without any action if the Execute parametertells us so. Still, return the
	# pass-through data to the calling application.
	if Execute == False:
		return PassThroughData, None, None, None

	# start memorizing some performance information for the execution of this tool
	PerformanceData = {}
	PerformanceData['NumNodes'] = NumNodes
	PerformanceData['NumCores'] = NumCores
	PerformanceData['NumCoresPerNode'] = NumCoresPerNode
	PerformanceData['Executable'] = Executable
	PerformanceData['NewControlFile'] = NewControlFile
	PerformanceData['Thread'] = Thread
	PerformanceData['Node'] = Node
	PerformanceData['Core'] = Core
	PerformanceData['Partition'] = Partition

	# Assemble the command line (except for the partition parameter)
	Command = '"' + Executable + '" ' + var.OPTIONS + ' "' + NewControlFile + '"'
	PerformanceData['Type'] = 'Single-Node-Serial'

	# Append the partition number if needed
	if Partition != None:
		Command += ' ' + str(Partition)
		PerformanceData['Type'] = 'Single-Node-Partitioned'

	# For multi-node jobs, add the ssh command to execute the command remotely (this is specific to the TRACC cluster for now).
	# Suppress the ssh command for the partitions to be run on the same node where the Python script is executing.
	if NumNodes > 1 and Node.replace('-ib','') != platform.node():
		Directory = os.path.abspath(var.WORKDIR).replace('\\','/')
		if Partition != None:
			Progress ('Starting partition '+str(Partition)+' on node "'+Node+'" core '+str(Core)+' thread '+str(Thread))
			PerformanceData['Type'] = 'Multi-Node-Partitioned'
		else:
			Progress ('Starting serial execution on node "'+Node+'" core '+str(Core)+' thread '+str(Thread))
			PerformanceData['Type'] = 'Multi-Node-Serial'
		Command = 'ssh -M -S /tmp/transims-thread-'+str(Thread)+' ' + Node + ' ( cd "' + Directory + '";' + Command + '; echo /-EXIT-code-/=$?)'
	PerformanceData['Command'] = Command

	# Split the command line into a stack for execution. Popen wants the arguments in a list.
	# The shlex module does this properly (considering double quotes correctly).
	Stack = shlex.split(Command)

	# Remember the current start time, and create a ring buffer for the lines to be received from standard output
	StartTime = time.time ()
	PerformanceData['StartTime'] = StartTime
	Buffer = deque ()

	# Open the pipe to execute the command. On Windows, set an IDLE priority class
	# so that the processes don't compete with the GUI or other foreground applications.
	# Found on: http://msdn.microsoft.com/en-us/library/bb521588(WinEmbedded.51).aspx
	# Other classes are: 16384=BELOWNORMAL, 32768=ABOVENORMAL, 128=HIGH, 64=IDLE, 32=NORMAL, 256=REALTIME
	if os.name == 'nt':
		Process = subprocess.Popen (Stack, bufsize=1, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=64)
	else:
		Process = subprocess.Popen (Stack, bufsize=1, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

	# Loop over standard output until it ends, Maintain a ring buffer of limited
	# size for all output generated, and terminate the loop when standard output
	# reports termination (empty string). The beginning of the line may contain a
	# crazy string with the exit code - this is a workaround to bypass the broken
	# ssh functionality of passing error codes in an unreliable fashion.
	ExitCode = None
	while True:

		Line = Process.stdout.readline ()
		if Line == "":
			break
		if Line[0:14] == '/-EXIT-code-/=':
			ExitCode = int(Line[14:])
		else:
			Buffer.append (Line)
			if len (Buffer) > var.TRACEBACK_LINES:
				Buffer.popleft ()
			ElapsedTime = time.time () - StartTime
			Lock.acquire()
			Filter (Partition, Line, var.SHOW_MODULE_OUTPUT)
			Lock.release()

	# Although standard output has stopped, we must still ensure that the process
	# has really ended
	Process.wait ()

	# If running on a single node without ssh, get the return code directly
	if ExitCode == None:
		ExitCode = Process.returncode

	# Send back the return code from the executable, as well as the ring buffer,
	# pass-through data, and performance data
	EndTime = time.time ()
	PerformanceData['EndTime'] = EndTime
	PerformanceData['ExecutionTime'] = EndTime - StartTime
	return PassThroughData, ExitCode, Buffer, PerformanceData




#=========================================================================================================================
def CreateDryRunFileIfNeeded (NewFile):
	"""
	This is an internal function creating a dry run file if the
	file in question doesn't exist yet. If the file exists, the function
	simply returns.
	"""

	# create dry run file if needed. Report an error if the action fails.
	if not os.path.exists (NewFile):
		Progress ('Dry Run Mode: Creating dummy file "' + NewFile + '"')
		try:
			File = open (NewFile, 'wt')
			File.write ('TRANSIMS RTE dry run test file!')
			File.close ()
		except:
			Error (100217,'Dry Run Mode: Unable to create dummy file "' + NewFile + '"')

	return




#=========================================================================================================================
def CleanupPlaceholders(CacheFile,PlaceholderFiles):
	"""
	This is an internal function that is used to automatically
	determine which placeholder files need to be deleted (at a
	minimum) to allow the cached execution scheme to recover
	if it detects a need for the real data files. Execution is
	stopped after this analysis, and the user has to restart the
	script to fully recover.
	"""

	# analyze dependencies in reverse execution order
	CacheFileTracker.reverse()
	Dependencies = []
	Dependencies.extend(PlaceholderFiles)
	NumRuns = 0
	CheckInput = False
	for Run in CacheFileTracker:
		NumRuns += 1
		NumDepsForRun = 0
		ShowMsg = True
		for Filename in Run:
			Cache = LoadCacheFromFile(Filename)
			if Cache == None:
				Error ( 100235,'Missing or invalid cache file: "'+str(Filename)+'"!' )
			CheckInput = False
			for Entry in Cache['Marker']:
				if Entry[3] == 'OUTPUT':
					if MakeAbsolutePath(Entry[0],Filename) in Dependencies:
						CheckInput = True
						break
			# Search through the input files of this tool and see whether it depends on
			# on files that have been replaced with placeholders
			if CheckInput:
				if ShowMsg:
					if NumRuns == 1:
						Progress ( 'Dependency analysis for current module "'+os.path.split(Cache['Data']['Executable'])[1].replace('.exe','')+'"!' )
					else:
						Progress ( 'Dependency analysis for module "'+os.path.split(Cache['Data']['Executable'])[1].replace('.exe','')+'" executed '+str(NumRuns-1)+' steps ago in the tool sequence!' )
					ShowMsg = False
				for Entry in Cache['Marker']:
					if Entry[3] == 'INPUT':
						AbsFilename = MakeAbsolutePath(Entry[0],Filename)
						Extension = AbsFilename[-4:]
						if Extension >= '.tAA' and Extension <= '.tZZ':
							Counter = 0
							while True:
								PartFile = GetPartitionFilename(AbsFilename[:-4],Counter)
								if os.path.exists(PartFile):
									file = open ( PartFile, 'rb' )
									Test = file.read(31)
									if Test == 'TRANSIMS RTE placeholder file!\n':
										if PartFile not in Dependencies:
											Dependencies.append(PartFile)
											NumDepsForRun += 1
											Progress ( 'Placeholder file "'+PartFile+'" must be deleted to recover cached script execution ('+str(NumRuns)+', '+str(NumDepsForRun)+')!' )
								Counter += 1
								if Counter > 200: # hardcoded limit of partitions in TRANSIMS
									break
						else:
							file = open ( AbsFilename, 'rb' )
							Test = file.read(31)
							if Test == 'TRANSIMS RTE placeholder file!\n':
								if AbsFilename not in Dependencies:
									Dependencies.append(AbsFilename)
									NumDepsForRun += 1
									Progress ( 'Placeholder file "'+AbsFilename+'" must be deleted to recover cached script execution ('+str(NumRuns)+', '+str(NumDepsForRun)+')!' )
						file.close()

	# delete all the placeholder files that seem to cause the cache failure
	for Entry in Dependencies:
		Progress ( 'Deleting file "'+Entry+'" to recover cached script execution during the next run!' )
		os.remove(Entry)

	return




#=========================================================================================================================
def ReplaceFilesWithPlaceholders(Pathname):
	"""
	Replace a set of files specified as a file pattern with
	placeholder files so that caching still works despite the fact
	these files have been actually deleted.
	"""

	# the string argument may contain templates that are expanded here
	Pathname = ExpandTemplate(Pathname)

	# create the list of files from the file pattern string
	Files = glob.glob(Pathname)

	# loop over the files
	Progress ( 'Replacing data files with placeholders: "' + Pathname + '"' )
	for File in Files:
		# .def files are ignored
		if File.endswith('.def') == False:
			# if this is already a placeholder file, we don't need to make it one
			File = os.path.abspath(File).replace('\\','/')
			file = open ( File, 'rb' )
			Test = file.read(31)
			if Test == 'TRANSIMS RTE placeholder file!\n':
				FileName = file.readline().strip()
				ModTime = file.readline().strip()
				Size = file.readline().strip()
				file.close()
			else:
				file.close()
				# create the placeholder file, but only if there is no corresponding .def file.
				# This is to protect files from being destroyed unless they are clearly
				# TRANSIMS files.
				ModTime = str(os.path.getmtime(File))
				Size = str(os.path.getsize(File))
				if os.path.exists(File+'.def'):
					file = open ( File, 'wb' )
					file.write ( 'TRANSIMS RTE placeholder file!\n' )
					file.write ( File + '\n' )
					file.write ( ModTime + '\n' )
					file.write ( Size + '\n' )
					file.write ( 'Comment: This file has been deleted as part\n' )
					file.write ( 'of the RTE script. The particular format of\n' )
					file.write ( 'this file allows the RTE caching to still work.\n' )
					file.write ( 'Do not delete or modify this file unless\n' )
					file.write ( 'caching is no longer needed.\n' )
					file.close()
					os.remove(File+'.def')
			Test = (File, ModTime, Size)
	return




#=========================================================================================================================
def CreateDirectory (Directory):
	"""
	This function vreate a directory specified in the string argument.
	The string is being expanded if a template is embedded.
	"""

	Directory = ExpandTemplate(Directory)
	try:
		Directory = str(Directory)
		if not os.path.exists(Directory):
			os.makedirs(Directory)
	except:
		Error(100769,'Unable to create the directory "'+str(Directory)+'"')
	return




#=========================================================================================================================
def Simplify (Value):
	"""
	This is an internal function that takes a text argument
	and tries to determine the type and return it in the
	most appropriate type. The result will be a boolean,
	integer, or float. It will be a string if none of the
	type conversions work.
	"""

	Value = Value.rstrip('%')
	if Value.isdigit():
		Value = int(Value)
	elif Value.upper() == 'TRUE':
		Value = True
	elif Value.upper() == 'FALSE':
		Value = False
	else:
		try:
			OrgValue = Value
			Value = float(Value)
		except:
			Value = OrgValue
	return Value




#=========================================================================================================================
def ExtractResults (ReportFile):
	"""
	This function is an internal function to analyze a typical
	PRN file to extract warning and result information from it.
	This information is then returned in from of a dictionary
	structure.
	"""

	Results = {}
	Results['WarningTypes'] = {}
	Results['Warnings'] = []
	Results['Variables'] = {}
	Message('Extracting results from "'+ReportFile+'"')
	File = open(ReportFile,'r')

	# remove page breaks
	CleanContent = []
	while True:
		Line = File.readline()
		if Line == '':
			break
		if Line.find('\f') >= 0:
			Line = Line.split('\f',1)[0].strip()
			CleanContent.append(Line)
			Line = File.readline()
			if Line == '':
				break
			Line = File.readline()
			if Line == '':
				break
			if Line.strip() != '':
				CleanContent.append(Line)
		else:
			CleanContent.append(Line)

	# extract results and warnings
	for Line in CleanContent:
		if Line != '':
			if Line.find(' = ') >= 0:
				Key,Value = Line.split('=',1)
				Key = Key.strip().upper().replace(' ','_').replace('-','_')
				Value = Value.strip().replace('\\','/')
				Words = Value.split()
				NumWords = len(Words)
				Parts = Value.split(',')
				NumParts = len(Parts)
				if NumWords == 1:
					Value = Simplify(Value)
				elif NumWords == 2 and Words[1].startswith('(') and Words[1].endswith('%)'):
					Value = Simplify(Words[1][1:-2])
					Results['Variables'][Key+'_PCT'] = Value
					Value = Simplify(Words[0])
				elif NumParts > 1:
					for i in range(len(Parts)):
						Parts[i] = Simplify(Parts[i].strip())
					if NumParts == 1:
						Value = Parts[0]
					else:
						Value = Parts
				else:
					if type(Simplify(Words[0])) in (int,float):
						IsUnit = True
						for i in range(1,NumWords):
							if type(Simplify(Words[i])) != str:
								IsUnit = False
								break
						if IsUnit:
							Value = Value[len(Words[0]):].strip()
							Results['Variables'][Key+'_UNIT'] = Value
							Value = Simplify(Words[0])
				if Key.strip() != '':
					Results['Variables'][Key] = Value
			elif Line.find('Warning:') == 0:
				Results['Warnings'].append(Line[9:])
				Words = Line.split()
				Line = ''
				for Word in Words:
					if Word != 'Warning:':
						if Word.isdigit():
							Line += 'X '
						else:
							Line += Word+' '
				Line = Line.strip()
				if Line not in Results['WarningTypes'].keys():
					Results['WarningTypes'][Line] = 1
				else:
					Results['WarningTypes'][Line] += 1
			elif Line.find('Process Complete') >= 0:
				Words = Line.split()
				Value = Words[len(Words)-1].strip(' ()')
				Results['Variables']['EXECUTION_TIME_STRING'] = Value
				Components = Value.split(':')
				NumComponents = len(Components)
				Factor = 1.0
				Seconds = 0.0
				for i in range(NumComponents):
					Seconds += int(Components[NumComponents-1-i]) * Factor
					Factor *= 60.0
				Results['Variables']['EXECUTION_TIME_SECONDS'] = Seconds

	# extract LinkSum network performance data
	BlockStarted = False
	for Line in CleanContent:
		if Line != '':
			if BlockStarted:
				Key = Line[1:28].strip().upper().replace(' ','_').replace('-','_')
				Value = Simplify(Line[29:46].strip())
				if Key.strip() != '':
					Results['Variables'][Key] = Value
			else:
				Words = Line.split()
				if Words == ['Time','Period','Total']:
					BlockStarted = True
		else:
			BlockStarted = False

	return Results




#=========================================================================================================================
def Progress (Message=None, ElapsedTime=None, Mark='', FromThread=False):
	"""
	An internal function that shows progress messages on the screen and
	log file. The line number of the currently executing
	script is determined with the inspect module.
	"""

	global JobStartTime,IsShowingDots,DotPosition,PrevElapsedTime,PreviousLine
	if ElapsedTime == None:
		ElapsedTime = time.time() - JobStartTime
	Days = int(ElapsedTime / 60 / 60 / 24)
	Hours = int(ElapsedTime / 60 / 60 - Days * 24)
	Minutes = int(ElapsedTime / 60 - Days *24 * 60 - Hours * 60)
	Seconds = int(ElapsedTime - Days *24 * 60 * 60 - Hours * 60 * 60 - Minutes * 60)
	TimeString = '%(Days)d.%(Hours)02d:%(Minutes)02d:%(Seconds)02d'%{'Days':Days,'Hours':Hours,'Minutes':Minutes,'Seconds':Seconds}
#	Fraction = int(ElapsedTime * 100 - Days *24 * 60 * 60 * 100 - Hours * 60 * 60 * 100 - Minutes * 60 * 100 - Seconds * 100)
#	TimeString = '%(Days)d.%(Hours)02d:%(Minutes)02d:%(Seconds)02d.%(Fraction)03d'%{'Days':Days,'Hours':Hours,'Minutes':Minutes,'Seconds':Seconds,'Fraction':Fraction}
	if var.SHOW_LINE_NUMBERS:
		Line = ''
		if FromThread == True:
			Line = PreviousLine
		else:
			tb = inspect.stack()
			for entry in tb:
				if not entry[1].endswith('__init__.py'):
					Line = '['+str(entry[2])+']'
					break
			PreviousLine = Line
		if Line != '':
			TimeString += ' ' + Line
	if var.OUTPUT_WIDTH > 0:
		Width = var.OUTPUT_WIDTH -3 - len(TimeString) - len(Mark)
	else:
		Width = 1000000 # produce just a very long line ...
	Output = ''
	if Message != None:
		if IsShowingDots:
			Output += '.\n'
			IsShowingDots = False
			LastDotShowTime = 0.0
			DotPosition = 0
			IsShowingDots = False
		Message = Message.strip()
		Output += TimeString+Mark+' '
		while True:
			Len = len(Message)
			if Len <= Width:
				Output += Message.strip()+'\n'
				break
			Pos = Message[0:Width].rfind(' ')
			if Pos < 0:
				Pos = Width
			if len(Message[0:Pos+1].strip()) > 0:
				Output += Message[0:Pos+1].strip()+'\n'
				Output += ' '*(len(TimeString)-1)+'|'+Mark+' '
			Message = Message [Pos+1:]
	else:
		if not IsShowingDots:
			IsShowingDots = True
			Output += TimeString+' '
			DotPosition = 0
		if ElapsedTime - PrevElapsedTime > 1:
			Output += '.'
			DotPosition += 1
			if DotPosition > 77:
				Output += '\n'
				Output += TimeString+' '
				DotPosition = 0
			PrevElapsedTime = ElapsedTime
	sys.stdout.write(Output)
	sys.stdout.flush()
	LogFile.write(Output)
	LogFile.flush()
	return




#=========================================================================================================================
def WriteFileIfDifferent (File,Content):
	"""
	This is an internal function that rewrites a file only
	if the content has changed. This will maintain the file
	modification date, and is used in writing for example
	control files. If the file is not written, the file modification
	date tells the caching algorithm that the control file
	is unchanged.
	"""

	if os.path.exists(File):
		try:
			file = open(File,"rb")
			Previous = file.read()
			file.close()
		except:
			Error (100935,'Unable to read "'+File+'"')
		if Previous == Content:
			return False
	try:
		file = open(File,"wb")
		file.write(Content)
		file.close()
	except:
		Error (100943,'Unable to write "'+File+'"')
	return True




#=========================================================================================================================
def Error(Code,Message):
	"""
	Internal function that will display error information and the
	stop execution of the script.
	"""

	try:
		Progress(' ')
		Progress('>>> ERROR '+str(Code)+' <<<')
		Progress(Message)
		raise RuntimeError
	except:
		tb = traceback.extract_stack()
		for i in range(len(tb)):
			if os.path.basename(tb[i][0]) != '__init__.py':
				Progress('Line '+str(tb[i][1])+' in "'+tb[i][0]+'":')
				Progress(str(tb[i][3]).strip())
		Progress(' ')
		sys.exit(1)
	return




#=========================================================================================================================
def Warning(Code,Message):
	"""
	Internal function that will display warning information and then
	continue execution of the script.
	"""

	try:
		Progress(' ')
		Progress('>>> WARNING '+str(Code)+' <<<')
		Progress(Message)
		raise RuntimeError
	except:
		tb = traceback.extract_stack()
		for i in range(len(tb)):
			if os.path.basename(tb[i][0]) != '__init__.py':
				Progress('Line '+str(tb[i][1])+' in "'+tb[i][0]+'":')
				Progress(str(tb[i][3]).strip())
		Progress(' ')
	return




#=========================================================================================================================
def Message(Message):
	"""
	Internal function that will display a debugging message during execution
	of the script.
	"""

	if var.DEBUG:
		Progress(Message)




#=========================================================================================================================
def FormatKeyValuePair (Key, Value):
	"""
	Utility function for formatting key/value pairs for control files
	that are written by RTE to invoke the actual tool. Keys are written
	in the first column of the output string, and the values are appended
	at a certain space-filled offset.
	"""

	String = Key
	for i in range(35-len(Key)):
		String += " "
	if type(Value) == list:
		for item in Value:
			String += str(item)+", "
		String = String.rstrip().rstrip(',')
	else:
		String += str(Value)
	return String




#=========================================================================================================================
def TranslateKeyIndex (Key, String):
	""""
	Utility function for translating lookup values for
	specific keys. This is a prototype for a user-level
	function, but is not ready yet. Implementation is
	currently only for one key. This needs to be designed in
	a more general fashion.
	"""
	if Key == "POCKET_LENGTHS_FOR_FACILITY":
		if String in FacilityType:
			return FacilityType[String]
		elif String in FacilityType.values():
			return String
		return 0
	else:
		return String




#=========================================================================================================================
class LockPID:
	"""
	This is a class that may fall out of use and may need
	reimplementation. The idea was to create an instance of
	this class at the startup of the RTE script. The process ID
	is written to a file, and the file is "unlocked" in the
	destructor. This way a script can be locked while being
	executed so that no second instance of RTE can work on it.
	This paradigm works only under Cygwin or Linux if executed
	on a single node. It does not work properly under Windows
	because there is no way to terminate a Python script that
	would invoke the destructor. On the cluster, it's of limited
	value because it's not possible to determine whether a script
	is being executed on another node. Thus, reimplementation
	is needed.
	"""
	#--------------------------------------------------------
	def __init__(self, PidFileName):
		self.PidFileName = PidFileName
		self.ResetFileOnExit = True
		if os.path.exists (PidFileName):
			PidFile = open(self.PidFileName, 'rt')
			Content = PidFile.read (128).strip()
			PidFile.close ()
			if Content != 'finished' and IgnorePidFile == False:
				self.ResetFileOnExit = False
				Error (101022,'Script is executing on "' + str ( Content ) + '" (see .pid file)')
		ProcessId = os.getpid()
		PidFile = open(self.PidFileName, 'wt')
		PidFile.write (platform.node() + ' '+str(ProcessId))
		PidFile.close ()
		return
	#--------------------------------------------------------
	def __del__(self):
		if self.ResetFileOnExit:
			PidFile = open(self.PidFileName, 'wt')
			PidFile.write ('finished')
			PidFile.close ()
		return
	#--------------------------------------------------------




#=========================================================================================================================
class WorkerThread ( threading.Thread ):
	"""
	This is an internal class that forms the basis for threaded
	execution. The calling application establishes as many instances
	of this class as there are cores accross all participating machines.
	All these threads are executing on a single core of a single node
	due to the fact that Python cannot run threads on multiple cores.
	Nevertheless, the worker threads do very little, thus there is no
	performance issue. Basically, the worker threads wait for work
	submitted through the work queue, and send results to the main
	thread by adding results to the result queue. To create the results,
	each thread calls an instance of the RuneExecutableInPipe function.
	This function needs little CPU time itself, because it creates a
	subprocess to execute the TRANSIMS tool and then simply watches over
	standard output from the TRANSIMS tool until that tool is done.
	The results are then sent to the result queue by the instance of this
	class, and the thread starts waiting for additional work. Once all work
	is finished (as indicated by the work queue), the thread stops execution
	and is ready to be joined to the main thread (the main thread will
	eventually collect the thread by calling the join function).
	"""
	#--------------------------------------------------------
	def __init__(self, Thread, Node, Core):
		self.Thread = Thread
		self.Node = Node
		self.Core = Core
		threading.Thread.__init__(self)
		return
	#--------------------------------------------------------
	def run(self):
		while True:
			if WorkQueue.qsize () > 0:
				data = WorkQueue.get ()
				if type (data) == str:
					if data == 'exit':
						break
				PassThroughData, Executable, NewControlFile, Partition, Execute = data
				Result = RunExecutableInPipe (PassThroughData, Executable, NewControlFile, self.Thread, self.Node, self.Core, Partition, Execute)
				ResultQueue.put(Result)
				time.sleep (1)
			else:
				time.sleep (1)
		return
	#--------------------------------------------------------




#=========================================================================================================================
class ControlKeys:
	"""
	This class is the core of the RTE functionality. Control key objects
	are instantiated from this class. They are manipulated by the user
	and finally "executed" by creating a control file and sending that to
	the execution through a TRANSIMS executable. Each control key object
	has a type, e.g. "Router" or "PlanSum". There are two special types
	that are less stringent in their use: "Generic" and "GlobalControlKeys".
	Both can accept any legal control key. "Generic" is a user-defined
	container for control keys that can be used to define a set of shared
	keys that are explicitly added to the control key set of any other type.
	"GlobalControlKeys" is pre-defined on the module level, and all keys
	added to this object are automatically added to any control key object
	upon execution, unless the same key is defined locally within that object.
	This implements the logic of global control keys.
	"""

	#--------------------------------------------------------
	def __init__(self, Template=None, ControlFile=None, ControlKeyObject=None, ReplaceKeys=None, AllowInvalidKeys=False, SkipUnusedKeys=False):
		"""
		This is the constructor of the ControlKeys class. The constructor has
		six parameters, all of which have default values. Some parameters
		can be used to allow replacement of existing keys in the object,
		to allow adding keys that are invalid keys for this object, and to
		ignore keys from the file that are not valid for this specific object.
		Others specify the type and initialization source for the new object.

		@type Template: String
		@param Template: The type of the control key objecy to be created.
		This is a case sensitive string such as 'PlanSum' or 'Router' identifying the
		requested type of control key object. If the parameter is not provided or
		is specified as None, the template defaults to 'Generic'. These generic control
		key objects can contain any valid TRANSIMS key, meaning that individual keys
		are not checked for applicability to a particular TRANSIMS tool.

		@type ControlFile: String
		@param ControlFile: The name of a control key file to be used to load
		control keys from. The file name is case sensitive on some operating systems
		and file systems, and a forward slash (the Linux convention for path component
		separators) should be used when specifying absolute or relative file names. The file must exists
		and must be readable by the application.

		@type ControlKeyObject: A ControlKeys Object
		@param ControlKeyObject: The name of an existing control key object to load
		control keys from. All control keys of that object will be copied into the
		new control key object. All keys will be checked for applicability to the
		control key object.

		@type ReplaceKeys: Boolean
		@param ReplaceKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. If a key is specified multiple times in the
		initialization set, subsequent redefinitions are silently accepted. By default,
		the redefinition of a key will terminate execution with an error message.

		@type AllowInvalidKeys: Boolean
		@param AllowInvalidKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. Even if a key is found to be illegal for
		a specific TRANSIMS tool, its definition is still accepted. This is different
		from L{SkipUnusedKeys}, where the key is simply ignored. By default,
		encountering an illegal key in the source will terminate execution with an error message.
		The use of this paramater should be a rare exception, and is meant to be a means of last resort
		to create and use control keys that are syntactically unknown to
		TRANSIMS Studio and the TRANSIMS Run Time Environment.

		@type SkipUnusedKeys: Boolean
		@param SkipUnusedKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. If a key is encountered in the source that is
		illegal for the current type of control key object, it is silently ignored.
		This is different from L{AllowInvalidKeys}, where the key is instead
		accepted into the new control key object. By default,
		encountering a key in the source that is invalid for the current control
		key object will terminate execution with an error message.

		@rtype: An Initialized ControlKeys Object
		@return: This is the constructor used to instantiate a new object.
		"""

		# the default control key object type is "Generic"
		if Template == None:
			Template = 'Generic'

		# check the template type and issue an error if it's illegal
		if type(Template) != str or ( Template not in ListOfKeys and Template != 'Generic' ):
			Error (101062,'Illegal control key template "'+str(Template)+'"')

		# store the template name so other member functions can access it, and
		# create dictionaries for the object's data
		self.Template = Template
		self.KeyArray = {}
		self.Results = {}

		# if this is the global control key object, print an initialization message on standard output. This special
		# object is created once at the end of the module, so this message is printed only once, and after the
		# module is fully initialized. The messages are written to both standard output and the log file.
		if Template == 'GlobalControlKeys':
			Output = ''
			Output += '\n      TRANSIMS RTE (Run Time Environment) Version ' + RTE_Version + '.' + str (RTE_Revision) + ' (' + RTE_Author + ')\n'
			Output += '        Transportation Research and Analysis Computing Center\n'
			Output += '                    Argonne National Laboratory\n\n'
			Output += '         Host Name: '+platform.node()+'\n'
			Output += ' Host Architecture: '+platform.machine()+'\n'
			Output += '    Host Processor: '+platform.processor()+'\n'
			Output += '     Host Platform: '+platform.platform()+'\n'
			Output += '    Python Version: '+platform.python_version()+'\n'
			Output += '   Number of Cores: '+str(NumCores)+'\n'
			if NumNodes > 1:
				Output += '   Number of Nodes: '+str(NumNodes)+'\n'
				for Node in NumCoresPerNode:
					Output += '    Cores per Node: '+Node+': '+str(NumCoresPerNode[Node])+'\n'
			Output += '       System Time: '+time.ctime()+'\n'
			Output += '  Operating System: '+platform.system()+'\n\n'
			sys.stdout.write(Output)
			LogFile.write(Output)
		else:
			Progress('Creating control key container for "'+Template+'"')

		# if the ControlFile parameter has been set, read a set of control keys
		# from that file
		if ControlFile != None:
			if ControlKeyObject != None:
				Error(101405,'Only one of the parameters "ControlFile" or "ControlKeyObject" may be specified on a call to ControlKeys()')
			self.FromFile(ControlFile, ReplaceKeys, AllowInvalidKeys, SkipUnusedKeys)
		return

		# if the ControlKeyObject parameter has been set, read a set of control keys
		# from that object
		if ControlKeyObject != None:
			if ControlFile != None:
				Error(101411,'Only one of the parameters "ControlFile" or "ControlKeyObject" may be specified on a call to ControlKeys()')
			self.FromObject(ControlKeyObject, ReplaceKeys, AllowInvalidKeys, SkipUnusedKeys)
		return

	#--------------------------------------------------------
	def __Replace (self, ReplaceKeys=None):
		"""
		This is an internal utility function that evaluates whether
		keys should be replacable at this time or not. The decision is made
		based on the value of the global variable and the argument passed
		to this function.
		"""
		if ReplaceKeys == None:
			return var.REPLACE_KEYS
		else:
			return ReplaceKeys
		return

	#--------------------------------------------------------
	def FromFile (self, ControlFile, ReplaceKeys=None, AllowInvalidKeys=False, SkipUnusedKeys=False):
		"""
		This is a user function to add control keys from a control file
		to the control key object. All keys are checked against the list
		of known keys and comments are removed. Three optional parameters
		can be used to allow replacement of existing keys in the object,
		to allow adding keys that are invalid keys for this object, and to
		ignore keys from the file that are not valid for this specific object.

		@type ControlFile: String
		@param ControlFile: The name of a control key file to be used to load
		control keys from. The file name is case sensitive on some operating systems
		and file systems, and a forward slash (the Linux convention for path component
		separators) should be used when specifying absolute or relative file names. The file must exists
		and must be readable by the application.

		@type ReplaceKeys: Boolean
		@param ReplaceKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. If a key is specified multiple times in the
		initialization set, subsequent redefinitions are silently accepted. By default,
		the redefinition of a key will terminate execution with an error message.

		@type AllowInvalidKeys: Boolean
		@param AllowInvalidKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. Even if a key is found to be illegal for
		a specific TRANSIMS tool, its definition is still accepted. This is different
		from L{SkipUnusedKeys}, where the key is simply ignored. By default,
		encountering an illegal key in the source will terminate execution with an error message.
		The use of this paramater should be a rare exception, and is meant to be a means of last resort
		to create and use control keys that are syntactically unknown to
		TRANSIMS Studio and the TRANSIMS Run Time Environment.

		@type SkipUnusedKeys: Boolean
		@param SkipUnusedKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. If a key is encountered in the source that is
		illegal for the current type of control key object, it is silently ignored.
		This is different from L{AllowInvalidKeys}, where the key is instead
		accepted into the new control key object. By default,
		encountering a key in the source that is invalid for the current control
		key object will terminate execution with an error message.

		@rtype: Nothing
		@return: The function adds keys to an existing control key object.
		"""

		Progress('Loading control keys for "' + self.Template + '" from "'+ControlFile+'"')
		try:
			File = open(ControlFile,"rb")
			Counter = 0
			for Line in File:
				Counter += 1
				Line = Line.strip()
				if Line[0:1] != '#' and Line != "":
					Pair = Line.split(None,1)
					if len(Pair) < 2:
						Error(101103,'Illegal control file syntax in line '+str(Counter)+' of the current control key file!')
					Key = Pair[0]
					Value = Pair[1]
					self.SetKey(Key,Value,ReplaceKeys,AllowInvalidKeys,SkipUnusedKeys)
		except IOError:
			Error(101108,'Cannot load keys from control file "'+str(ControlFile)+'"')
		return

#--------------------------------------------------------
	def FromString (self, ControlKeyString, ReplaceKeys=None, AllowInvalidKeys=False, SkipUnusedKeys=False):
		"""
		This is a user function to add control keys from a Python string
		to the control key object. All keys are checked against the list
		of known keys and comments are removed. Three optional parameters
		can be used to allow replacement of existing keys in the object,
		to allow adding keys that are invalid keys for this object, and to
		ignore keys from the string that are not valid for this specific object.

		@type ControlKeyString: String
		@param ControlKeyString: A Python string to be used to load
		control keys from. This is typically a triple-quoted string that
		allows for the easy embedding of control key specifications right into
		the Python code.

		@type ReplaceKeys: Boolean
		@param ReplaceKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. If a key is specified multiple times in the
		initialization set, subsequent redefinitions are silently accepted. By default,
		the redefinition of a key will terminate execution with an error message.

		@type AllowInvalidKeys: Boolean
		@param AllowInvalidKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. Even if a key is found to be illegal for
		a specific TRANSIMS tool, its definition is still accepted. This is different
		from L{SkipUnusedKeys}, where the key is simply ignored. By default,
		encountering an illegal key in the source will terminate execution with an error message.
		The use of this paramater should be a rare exception, and is meant to be a means of last resort
		to create and use control keys that are syntactically unknown to
		TRANSIMS Studio and the TRANSIMS Run Time Environment.

		@type SkipUnusedKeys: Boolean
		@param SkipUnusedKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. If a key is encountered in the source that is
		illegal for the current type of control key object, it is silently ignored.
		This is different from L{AllowInvalidKeys}, where the key is instead
		accepted into the new control key object. By default,
		encountering a key in the source that is invalid for the current control
		key object will terminate execution with an error message.

		@rtype: Nothing
		@return: The function adds keys to an existing control key object.
		"""

		Progress('Loading control keys for "' + self.Template + '" from a string')
		if type(ControlKeyString) == str:
			File = ControlKeyString.split('\n')
			Counter = 0
			for Line in File:
				Counter += 1
				Line = Line.strip()
				if Line[0:1] != '#' and Line != "":
					Pair = Line.split(None,1)
					if len(Pair) < 2:
						Error(101121,'Illegal control file syntax in line '+str(Counter)+' of the current control key string!')
					Key = Pair[0]
					Value = Pair[1]
					self.SetKey(Key,Value,ReplaceKeys,AllowInvalidKeys,SkipUnusedKeys)
		else:
			Error(101126,'Keys can only be loaded from a string, not from a variable of type "'+type(ControlKeyString)+'"')
		return

	#--------------------------------------------------------
	def __IsControlKeyObject (self,ControlKeyObject):
		"""
		This is an internal fucntion that determines the Python type of
		the object passed as an argument and returns true if it is
		a valid control key object.
		"""

		if type(ControlKeyObject).__name__ == 'instance':
			if ControlKeyObject.__class__.__name__ == 'ControlKeys':
				return True
		return False

	#--------------------------------------------------------
	def FromObject (self, ControlKeyObject, ReplaceKeys=None, AllowInvalidKeys=False, SkipUnusedKeys=False):
		"""
		This is a user function to add control keys from another control key object
		to the current control key object. All keys are checked against the list
		of known keys. Three optional parameters
		can be used to allow replacement of existing keys in the object,
		to allow adding keys that are invalid keys for this object, and to
		ignore keys from the object that are not valid for this specific object.

		@type ControlKeyObject: A ControlKeys Object
		@param ControlKeyObject: The name of an existing control key object to load
		control keys from. All control keys of that object will be copied into the
		new control key object. All keys will be checked for applicability to the
		control key object.

		@type ReplaceKeys: Boolean
		@param ReplaceKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. If a key is specified multiple times in the
		initialization set, subsequent redefinitions are silently accepted. By default,
		the redefinition of a key will terminate execution with an error message.

		@type AllowInvalidKeys: Boolean
		@param AllowInvalidKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. Even if a key is found to be illegal for
		a specific TRANSIMS tool, its definition is still accepted. This is different
		from L{SkipUnusedKeys}, where the key is simply ignored. By default,
		encountering an illegal key in the source will terminate execution with an error message.
		The use of this paramater should be a rare exception, and is meant to be a means of last resort
		to create and use control keys that are syntactically unknown to
		TRANSIMS Studio and the TRANSIMS Run Time Environment.

		@type SkipUnusedKeys: Boolean
		@param SkipUnusedKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. If a key is encountered in the source that is
		illegal for the current type of control key object, it is silently ignored.
		This is different from L{AllowInvalidKeys}, where the key is instead
		accepted into the new control key object. By default,
		encountering a key in the source that is invalid for the current control
		key object will terminate execution with an error message.

		@rtype: Nothing
		@return: The function adds keys to an existing control key object.
		"""

		Progress('Loading control keys for "' + self.Template + '" from an object')
		if self.__IsControlKeyObject(ControlKeyObject):
			for Key in ControlKeyObject.KeyArray:
				self.SetKey(Key,ControlKeyObject.KeyArray[Key],ReplaceKeys,AllowInvalidKeys,SkipUnusedKeys)
		else:
			Error(101140,'Keys can only be loaded from an object, not from a variable of type "'+str(type(ControlKeyObject))+'"')

	#--------------------------------------------------------
	def __StripDimensionsFromKey (self,Key):
		"""
		This is an internal function that takes the name of a key and
		strips all possible dimensions from it. The dimensions are identified
		by consisting of digits and underscores at the end of a control key
		name. This is an imperfect method and may fail for some keys
		that end with a digit. To avoid this scenario, the keys are first
		checked against the key name database, and dimensions are only stripped off
		if the key is not found there.
		"""

		Test = Key
		for Dimension in range(8):
			if self.Template == 'Generic' or Test in ListOfKeys[self.Template]:
				return Test
			Test = Key.rstrip('0123456789_')
		return Key

	#--------------------------------------------------------
	def SetKey (self, Key, Value, ReplaceKeys=None, AllowInvalidKeys=False, SkipUnusedKeys=False):
		"""
		This is a user function to add a control key and its value
		to the control key object. All key is checked against the list
		of known keys. Three optional parameters
		can be used to allow replacement of an existing key in the object,
		to allow adding the key if it is otherwise invalid for this object, and to
		ignore the key if it is not valid for this specific object.

		@type Key: String
		@param Key: The name of a control key to be set. The key must not exist yet
		unless one of the other options relaxes the strict syntax checking rules.

		@type Value: String, Boolean, or Numerical
		@param Value: The value for the control key. This can be any appropriate variable type.
		Values can contain template definitions, embedded as a keyword enclosed in @ signs.

		@type ReplaceKeys: Boolean
		@param ReplaceKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. If a key is specified multiple times in the
		initialization set, subsequent redefinitions are silently accepted. By default,
		the redefinition of a key will terminate execution with an error message.

		@type AllowInvalidKeys: Boolean
		@param AllowInvalidKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. Even if a key is found to be illegal for
		a specific TRANSIMS tool, its definition is still accepted. This is different
		from L{SkipUnusedKeys}, where the key is simply ignored. By default,
		encountering an illegal key in the source will terminate execution with an error message.
		The use of this paramater should be a rare exception, and is meant to be a means of last resort
		to create and use control keys that are syntactically unknown to
		TRANSIMS Studio and the TRANSIMS Run Time Environment.

		@type SkipUnusedKeys: Boolean
		@param SkipUnusedKeys: This boolean parameter can be used to relax the
		rigidity of syntax enforcement. If a key is encountered in the source that is
		illegal for the current type of control key object, it is silently ignored.
		This is different from L{AllowInvalidKeys}, where the key is instead
		accepted into the new control key object. By default,
		encountering a key in the source that is invalid for the current control
		key object will terminate execution with an error message.

		@rtype: Nothing
		@return: The function adds keys to an existing control key object.
		"""

		Test = self.__StripDimensionsFromKey(Key)
		if self.Template != 'Generic':
			if SkipUnusedKeys == True:
				if Test not in ListOfKeys[self.Template]:
					return False
			if AllowInvalidKeys == False:
				if Test not in ListOfKeys[self.Template]:
					Error (101158,'Illegal key "'+Test+'" for control key object "'+self.Template+'". If you want to force the control key object to accept this key, specify "AllowInvalidKeys=True" when calling this function.')
		if type(Value) == dict:
			for Item in Value:
				self.SetKey(Key+"_"+str(TranslateKeyIndex(Key,Item)),Value[Item],ReplaceKeys,AllowInvalidKeys,SkipUnusedKeys)
		else:
			if Key not in self.KeyArray:
				self.KeyArray[Key] = Value
			else:
				if self.__Replace(ReplaceKeys) == False:
					Error (101167,'The key "'+Key+'" exists already in the "'+self.Template+'" object. This error message can be avoided by specifying the "ReplaceKeys=True" parameter on the function call, or by setting the global variable REPLACE_KEYS to True (var.REPLACE_KEYS = True).')
				else:
					if ReplaceKeys == None: # Give a warning if this replacement is enabled through a global setting only
						Warning(101184,'The key '+Key+' has been replaced with the value "'+str(Value)+'". It was previously set to "'+str(self.KeyArray[Key])+'"')
					self.KeyArray[Key] = Value
		return True

	#--------------------------------------------------------
	def GetKey (self, Key, Default=None, LocalOnly=False):
		"""
		Retrieve the value for a key from the internal database. A default
		can be specified, and if the key has not been set yet, this default
		value will be returned. The search can be limited to the local
		scope, e.g. to avoid retrieving the key's value specified in the
		global control object. This version of the function does not expand
		templates in the key's value.
		
		@note: Needs additional documentation!
		"""

		if Key in self.KeyArray:
			return self.KeyArray[Key]
		if LocalOnly == False:
			if Key in GlobalKeys.KeyArray:
				return GlobalKeys.KeyArray[Key]
		if Default == None:
			Error(101181,'Attempting to access an undefined control key "'+str(Key)+'"')
		return Default

	#--------------------------------------------------------
	def GetFinalKey (self, Key, Default=None, LocalOnly=False):
		"""
		Retrieve the value for a key from the internal database. A default
		can be specified, and if the key has not been set yet, this default
		value will be returned. The search can be limited to the local
		scope, e.g. to avoid retrieving the key's value specified in the
		global control object. This version of the function expands templates
		in the retrieved value if the value is a string.
		
		@note: Needs additional documentation!
		"""

		Value = self.GetKey(Key, Default, LocalOnly)
		if type(Value) == str:
			Value = ExpandTemplate(Value)
		return Value

	#--------------------------------------------------------
	def DelKey (self, Key):
		"""
		Remove a key and its value from the control key object.
		
		@note: Needs additional documentation!
		"""

		if Key in self.KeyArray:
			del self.KeyArray[Key]
		return

	#--------------------------------------------------------
	def GetCtl (self):
		"""
		Retrieve a string with the complete control key object
		in a string. The string contains annotations indicating
		template expansions and the use of local and global keys.
		This string is typically written into a file by the "Run"
		function before a TRANSIMS tool is executed. A user may use
		this function to dump a control key object into a file.
		
		@note: Needs additional documentation!
		"""

		String = '#!TRANSIMS/RTE\n#\n# Generated by TRANSIMS RTE Version '+RTE_Version+'\n'
		String += '# This file should not be edited directly. Changes\n'
		String += '# will be lost when running the TRANSIMS RTE scripts.\n'
		# local keys
		String += "#\n# The following control keys were explicitly set for "+self.Template+"\n#\n"
		Keys = self.KeyArray.keys()
		Keys.sort()
		for Key in Keys:
			Value = str(self.KeyArray[Key])
			for Variable in var.List():
				NewValue = Value.replace("@"+Variable+"@",str(var.Get(Variable)))
				if NewValue != Value:
					String += '# Variable replacement: '+Variable+' <==> "'+str(var.Get(Variable))+'"\n'
					String += '# Original key value: "'+Key+' = '+self.KeyArray[Key]+'"\n'
					Value = NewValue
			if Key in GlobalKeys.KeyArray.keys():
				if self.KeyArray[Key] != GlobalKeys.KeyArray[Key]:
					String += '# Inconsistent with global key: "'+Key+' = '+GlobalKeys.KeyArray[Key]+'"\n'
			String += FormatKeyValuePair(Key,Value)+"\n"
		# global keys except where local keys are defined
		Keys = []
		for Key in GlobalKeys.KeyArray.keys():
			if Key not in self.KeyArray:
				if Key in ListOfKeys[self.Template]:
					Keys.append(Key)
		Keys.sort()
		String += "#\n# The following control keys were set from global defaults\n#\n"
		for Key in Keys:
			Value = GlobalKeys.KeyArray[Key]
			for Variable in var.List():
				NewValue = Value.replace("@"+Variable+"@",str(var.Get(Variable)))
				if NewValue != Value:
					String += '# Variable replacement: '+Variable+' <==> "'+str(var.Get(Variable))+'"\n'
					String += '# Original key value: "'+Key+' = '+GlobalKeys.KeyArray[Key]+'"\n'
					Value = NewValue
			String += FormatKeyValuePair(Key,Value)+"\n"
		# check for remaining unmatched variables
		for Line in String.split('\n'):
			Line = Line.strip()
			if not Line.startswith('#'):
				match = re.search('@.*@',Line)
				if match != None:
					Error (101237,'The control key entry for "'+self.Template+'" contains an undefined variable "'+match.group(0)+'" in key "'+Line.split()[0]+'". Use the "var.'+match.group(0).strip('@')+' = Value" statement to assign a replacement value or remove the variable from this control key.')
		String += "#\n# End of the "+self.Template+" control file\n#"
		return String

	#--------------------------------------------------------
	def __GetPrnFileName (self, ControlFile, Partition=None):
		"""
		This is an internal function that determines the name of the
		TRANSIMS log file (PRN file) that will be written by the tool.
		This would be usually the name of the corresponding control file,
		but could also be another file specified as REPORT_FILE key.
		"""

		if 'REPORT_FILE' in self.KeyArray:
			PrnFile = self.GetFinalKey('REPORT_FILE',LocalOnly=True)
		elif 'REPORT_FILE' in GlobalKeys.KeyArray:
			Warning(101260,'The global control key "REPORT_FILE" will be used as the report file name for this run. This is not a good idea, making it ambiguous where reports end up. Specify the "REPORT_FLAG" directly in a control key object, or use the default PRN file logic to create the file.')
			PrnFile = GlobalKeys.GetFinalKey('REPORT_FILE')
		else:
			PrnFile = os.path.splitext(ControlFile)[0]+'.prn'
		if Partition != None:
			Base,Extension = os.path.splitext(PrnFile)
			PrnFile = Base+'_'+str(Partition)+Extension
		return PrnFile

	#--------------------------------------------------------
	def __GetInputFileKeys (self):
		"""
		This function returns a list of all keys that specify input network files.
		The list includes only names of keys that are in the global or local
		key lists. The function returns a list of strings containing control keys.
		"""

		Result = []
		for Key in self.KeyArray:
			if self.__IsInputFile(self.__StripDimensionsFromKey(Key)):
				Result.append(Key)
		for Key in GlobalKeys.KeyArray:
			if GlobalKeys.__IsInputFile(GlobalKeys.__StripDimensionsFromKey(Key)):
				if GlobalKeys.__StripDimensionsFromKey(Key) not in Result:
					Result.append(Key)
		return Result

	#--------------------------------------------------------
	def __GetOutputFileKeys (self):
		"""
		This function returns a list of all keys that specify output network files.
		The list includes only names of keys that are in the global or local
		key lists. The function returns a list of strings containing control keys.
		"""

		Result = []
		for Key in self.KeyArray:
			if self.__IsOutputFile(self.__StripDimensionsFromKey(Key)):
				Result.append(Key)
		for Key in GlobalKeys.KeyArray:
			if GlobalKeys.__IsOutputFile(GlobalKeys.__StripDimensionsFromKey(Key)):
				if GlobalKeys.__StripDimensionsFromKey(Key) not in Result:
					Result.append(Key)
		return Result

	#--------------------------------------------------------
	def __IsFile (self,Key):
		"""
		This function determines whether a value specified in a certain
		key is a file or not. The function returns True or False. Illegal keys
		also cause False to be returned.
		"""

		if GlobalKeys.__StripDimensionsFromKey(Key) in ListOfKeys['GlobalControlKeys']:
			return ListOfKeys['GlobalControlKeys'][GlobalKeys.__StripDimensionsFromKey(Key)]['IsFile']
		else:
			return False

	#--------------------------------------------------------
	def __IsNetworkFile (self,Key):
		"""
		This function determines whether a value specified in a certain
		key is a network file or not. The function returns True or False. Illegal keys
		also cause False to be returned.
		"""

		if self.__IsFile(Key):
			return ListOfKeys['GlobalControlKeys'][GlobalKeys.__StripDimensionsFromKey(Key)]['IsNetwork']
		else:
			return False

	#--------------------------------------------------------
	def __IsInputNetworkFile (self,Key):
		"""
		This function determines whether a value specified in a certain
		key is an input network file or not. The function returns True or False. Illegal keys
		also cause False to be returned.
		"""

		if self.__IsNetworkFile(Key):
			return ListOfKeys['GlobalControlKeys'][GlobalKeys.__StripDimensionsFromKey(Key)]['IsInput']
		else:
			return False

	#--------------------------------------------------------
	def __IsOutputNetworkFile (self,Key):
		"""
		This function determines whether a value specified in a certain
		key is an output network file or not. The function returns True or False. Illegal keys
		also cause False to be returned.
		"""

		if self.__IsNetworkFile(Key):
			return (not ListOfKeys['GlobalControlKeys'][GlobalKeys.__StripDimensionsFromKey(Key)]['IsInput'])
		else:
			return False

	#--------------------------------------------------------
	def __IsInputFile (self,Key):
		"""
		This function determines whether a value specified in a certain
		key is an input file or not. The function returns True or False. Illegal keys
		also cause False to be returned.
		"""

		if self.__IsFile(Key):
			return ListOfKeys['GlobalControlKeys'][GlobalKeys.__StripDimensionsFromKey(Key)]['IsInput']
		else:
			return False

	#--------------------------------------------------------
	def __IsOutputFile (self,Key):
		"""
		This function determines whether a value specified in a certain
		key is an output file or not. The function returns True or False. Illegal keys
		also cause False to be returned.
		"""

		if self.__IsFile(Key):
			return (not ListOfKeys['GlobalControlKeys'][GlobalKeys.__StripDimensionsFromKey(Key)]['IsInput'])
		else:
			return False

	#--------------------------------------------------------
	def Run (self, NewControlFile=None, Protect=False, Partitioned=False, ForceExecution=False):
		"""
		This is a user function that is called to execute the TRANSIMS tool
		with the control key information contained in the object. The keys
		are written to the control key file specified as an argument, and the
		TRANSIMS tool is invoked on this file.
		
		@note: Needs additional documentation!
		"""

		# check some basic error conditions
		if self.Template in ('Generic', 'GlobalControlKeys'):
			Error(101406,'"'+self.Template+'" objects are not executable')
		#
		if Partitioned == True and ListOfMetaData [ self.Template ] [ 'PARTITION' ] == False:
			Error(101409,'"'+self.Template+'" cannot run in partitoned mode')
		#
		if Partitioned:
			Progress('Preparing the execution of "'+self.Template+'" (partitioned mode)')
		else:
			Progress('Preparing the execution of "'+self.Template+'"')
		#
		if NodeFile != None:
			CreateStats(self.Template)

		# Change to the working directory. The working directory may have changed
		# between calls to TRANSIMS executables, although that's really not a good
		# idea. For all operating systems, directories will be seporated by a forward
		# slash (that's perfectly permissible). The directory will be created if possible.
		Directory = os.path.abspath(var.WORKDIR).replace('\\','/')
		if not os.path.exists(Directory):
			Message ('Creating new working directory "'+Directory+'"')
			try:
				os.makedirs(DirName)
			except:
				Error (101431,'Unable to create the new working directory "'+Directory+'"')
		try:
			os.chdir(Directory)
		except:
			Error (101435,'Unable to change into the working directory "'+Directory+'"')
		Message('The working directory is "'+str(Directory)+'"')

		# Assemble the path to the executable and check whether it exists.
		# The BINDIR may be relative to the current working directory,
		# which has been changed into above. If an executable cannot be found
		# in this directory, append the ".exe" extension and try again.
		Executable = None
		if var.BINDIR == None:
			Error (101445,'The TRANSIMS module executable for "'+self.Template+'" cannot be located. Directories for binaries must be specified using the "var.BINDIR" variable or correctly configured in the "Edit/Settings" menu of TRANSIMS Studio. "var.BINDIR" is currently not set at all. Please set it to an appropriate directory. If you want to search multiple directories, separate them with colons (;).')
		BinDirs = var.BINDIR.split(';')
		for BinDir in BinDirs:
			BinDir = os.path.abspath(BinDir.strip()).replace('\\','/')
			if not os.path.exists(BinDir):
				continue
			Executable = os.path.join(BinDir,self.Template).replace('\\','/')
			if not os.path.exists(Executable):
				if not os.path.exists(Executable+".exe"):
					continue
				else:
					Executable += ".exe"
					break
		if Executable == None:
			Error (101459,'The TRANSIMS module executable for "'+self.Template+'" cannot be located. Directories for binaries must be specified using the "var.BINDIR" variable or correctly configured in the "Edit/Settings" menu of TRANSIMS Studio. The current value of "var.BINDIR" is "'+str(var.BINDIR)+'". If you want to search multiple directories, separate them with colons (;).')

		# initialize cache dictionaries
		NewCacheTest = []
		NewCache = {}
		NewCache['Marker'] = []
		NewCache['Data'] = {}
	
		# Assemble the path to the new control file to be written. These control
		# files have a string embedded in the first line of the file, of the form
		# "#!/TRANSIMS/RTE". Control files will be protected from being
		# overwritten if they don't contain this marker.
		# If no control file was specified in the call to this function, a control
		# file will be created in the current working directory.
		if NewControlFile == None:
			NewControlFile = self.Template+".ctl"

		# We also substitute templates here to make programming easier for the user
		NewControlFile = ExpandTemplate(NewControlFile)

		# Create the final new control file name
		NewControlFile = os.path.abspath(os.path.join(Directory,NewControlFile)).replace('\\','/')
		Message('Creating new control file "'+str(NewControlFile)+'"')
		DirName = os.path.dirname(NewControlFile)
		if not os.path.exists(DirName):
			try:
				os.makedirs(DirName)
			except:
				Error (101489,'Unable to create directory "'+DirName+'"')
		if Protect == True and os.path.exists(NewControlFile):
			Error (101491,'Control key file "'+NewControlFile+'" exists')
		if os.path.exists(NewControlFile):
			try:
				File = open(NewControlFile,'r')
				Test = File.readline().strip();
				File.close()
			except:
				Error (101498,'Unable to read from control file "'+NewControlFile+'"')
			if Test != '#!TRANSIMS/RTE':
				Error (101500,'The control file "'+NewControlFile+'" exists and is not a TRANSIMS RTE control file. Files that have been generated automatically by the TRANSIMS RTE environment have a special marker in the first line indicating that they can be safely overwritten. The file that you are trying to write to is probably a manually written control file and has been prevented from being destroyed. If this is in error, delete this file and rerun the script.')
		Modified = WriteFileIfDifferent(NewControlFile,self.GetCtl())

		# Add the executable and the control file to the cache
		NewCache['Marker'].append((MakeRelativePath(Executable, NewControlFile), str(os.path.getmtime(Executable)), str(os.path.getsize(Executable)), 'EXE'))
		NewCacheTest.append((MakeRelativePath(Executable, NewControlFile), str(os.path.getmtime(Executable)), str(os.path.getsize(Executable)), 'EXE'))
		NewCache['Marker'].append((MakeRelativePath(NewControlFile, NewControlFile), str(os.path.getmtime(NewControlFile)), str(os.path.getsize(NewControlFile)), 'CTL'))
		NewCacheTest.append((MakeRelativePath(NewControlFile, NewControlFile), str(os.path.getmtime(NewControlFile)), str(os.path.getsize(NewControlFile)), 'CTL'))

		if Partitioned:
			NumPartitions = var.NUM_PARTITIONS
			NumThreads = NumCores
		else:
			NumPartitions = 1
			NumThreads = 1
		if EmbedGuiHints:
			Lock.acquire()
			print '@GUI@ EXE',self.Template,Partitioned,NumPartitions
			Lock.release()

		Message ('Starting worker threads')
		Thread = 0
		for Node in NumCoresPerNode:
			for Core in range(NumCoresPerNode[Node]):
				if Thread < NumThreads:
					ArrayOfWorkerThreads[Thread] = WorkerThread (Thread, Node, Core)
					ArrayOfWorkerThreads[Thread].setDaemon (True)
					ArrayOfWorkerThreads[Thread].start ()
				Thread += 1

		# Submit all partitions to the work queue
		NewCacheArray = {}
		NewCacheTestArray = {}
		NumInputPlaceHolderFiles = 0
		for Partition in range (NumPartitions):
			self.Results[Partition] = {}
			NewCacheArray[Partition] = copy.deepcopy(NewCache)
			NewCacheTestArray[Partition] = copy.deepcopy(NewCacheTest)
			NumInputPlaceHolderFiles += self.__RunIfNeeded(Directory, Partitioned, NewCacheArray[Partition], NewCacheTestArray[Partition], Protect, NewControlFile, Executable, NumThreads, Partition, ForceExecution)

		if NumInputPlaceHolderFiles > 0:
			Progress ( '"'+self.Template+'" depends on '+str(NumInputPlaceHolderFiles)+' placeholder files created by the ReplaceFilesWithPlaceholders() function' )

		# Submit as meany "exit" request to the end of the work queue as there are partitions.
		# Each of these requests will terminate a worker thread so that they are all down
		# after execution of the tool finishes.
		Message ('Asking worker threads to shut down when done')
		for i in range (NumThreads):
			WorkQueue.put ('exit')

		# Read a corresponding number of results from the queue, but not in dry run mode
		if var.DRY_RUN == False:
			for Index in range (NumPartitions):
				while True:
					if ResultQueue.qsize () > 0:
						PassThroughData, ExitCode, Buffer, PerformanceData = ResultQueue.get ()
						break
					else:
						time.sleep (1)

				Partitioned, Directory, Partition, ReportFile, NewCache, CacheFile, Protect, CachedExitCode, NumPartsOutput = PassThroughData
				if ExitCode == None:
					ExitCode = CachedExitCode
				NumWarnings = self.__PostProcessRun (ExitCode, Buffer, PerformanceData, Partitioned, Directory, Partition, ReportFile, NewCache, CacheFile, Protect, NumPartsOutput)
				if EmbedGuiHints:
					Lock.acquire()
					print '@GUI@ RES',NumWarnings,Partition,ExitCode
					Number = len(self.Results[Partition]['WarningTypes'])
					for Entry in self.Results[Partition]['WarningTypes']:
						print '@GUI@ WTP',Number,Partition,Entry
					Number = len(self.Results[Partition]['Warnings'])
					for Entry in self.Results[Partition]['Warnings']:
						print '@GUI@ WRN',Number,Partition,Entry
					print '@GUI@ CCH',NumPartitions,Partition,CacheFile
					Lock.release()

		# this is where the worker threads are physically taken down. 
		# They have already been terminated at this time.
		Message ('Taking down worker threads')
		for i in range (NumThreads):
			ArrayOfWorkerThreads[i].join ()
		Message ('All worker threads are down')
		#
		if NodeFile != None:
			CreateStats(Start=False)

		CacheFiles = []
		if NumPartitions == 1:
			FileName = os.path.splitext(NewControlFile)[0]+'.cache'
			CacheFiles.append(FileName)
			if not os.path.exists(FileName):
				Error (101591,'Cache file "'+FileName+'" should have been created!')
		else:
			for i in range(NumPartitions):
				FileName = os.path.splitext(NewControlFile)[0]+'_'+str(i)+'.cache'
				CacheFiles.append(FileName)
				if not os.path.exists(FileName):
					Error (101597,'Cache file "'+FileName+'" should have been created!')
		CacheFileTracker.append(CacheFiles)

		return True

	#--------------------------------------------------------
	def __TestOutputFile (self, Key, NewFile, ReferenceFile, Protect, Silent=True):
		"""
		This is an internal function that is used to test whether
		an output file exists before execution. It returns a tuple of
		information, with the relative file name derived from the given file
		name, the last file modification date, the file size, and the string
		"OUTPUT". If the file exists, it is checked for a signature that
		identifies it as a placeholder file. In this case, the file modification date
		and file size are read from this signature instead of the directory entry.
		A reference file is used as the anchor to determine the relative path
		to the output file (from the location of this reference file). A flag called
		"Protect" can be given as an argument. In this case, an existing file leads
		to an error message, to prevent the existing file to be overwritten. Another
		parameter, "Silent", allows for suppressing the progress message even if
		IO message are supposed to be shown in the log.
		"""

		# if the file exists, and has been been created in dry run mode, delete it so it will be like writing a new file
		ReplaceMsg = 'create'
		if os.path.exists(NewFile):
			file = open(NewFile,'rt')
			Test = file.read(100)
			file.close()
			if Test == 'TRANSIMS RTE dry run test file!':
				os.remove(NewFile)

		# if the file exists, check whether its a placeholder file., and if yes, get date and sie from there
		if os.path.exists(NewFile):
			file = open ( NewFile, 'rb' )
			Test = file.read(31)
			if Test == 'TRANSIMS RTE placeholder file!\n':
				FileName = file.readline().strip()
				ModTime = file.readline().strip()
				Size = file.readline().strip()
				Test = (MakeRelativePath(NewFile,ReferenceFile), ModTime, Size, 'OUTPUT')
				ReplaceMsg = 'placeholder'
			else:
				# it's not a placeholder file, so this may be a candidate for overwriting
				ReplaceMsg = 'replace'
				Test = (MakeRelativePath(NewFile,ReferenceFile), str(os.path.getmtime(NewFile)), str(os.path.getsize(NewFile)), 'OUTPUT')
			file.close()
		else:
			# the file doesn't exist, so there is little information to return
			Test = (MakeRelativePath(NewFile,ReferenceFile), None, None, None)

		# verify that the file can be written to. First create the directory, if needed.
		if Silent == False:
			Message('Verifying that output file "'+Key+'" = "'+NewFile+'" can be written')
		DirName = os.path.dirname(NewFile)
		if not os.path.exists(DirName):
			try:
				os.makedirs(DirName)
			except:
				Error (101632,'Unable to create output directory "'+DirName+'"')
		if os.path.exists(NewFile):
			if Protect == True:
				Error (101635,'Output file "'+NewFile+'" exists')
		if Silent == False:
			if var.SHOW_IO_FILES:
				Progress ('"'+self.Template+'" output file: "'+NewFile+'" ('+ReplaceMsg+")")
		return Test

	#--------------------------------------------------------
	def __TestInputFile (self, Key, NewFile, ReferenceFile):
		"""
		This is an internal function that is used to test whether
		an input file exists before execution. It returns a tuple of
		information, with the relative file name derived from the given file
		name, the last file modification date, the file size, and the string
		"INPUT". The file is checked for a signature that identifies it as a
		placeholder file. In this case, the file modification date
		and file size are read from this signature instead of the directory entry.
		A reference file is used as the anchor to determine the relative path
		to the input file (from the location of this reference file). It also
		returns a second argument that is 0 if this isn't a placeholder file, and
		1 if it is. This allows the calling function to count how many placeholder
		files are being used on input.
		"""

		# it is a fatal error for an input file not to exists
		Message('Verifying that input file "'+Key+'" = "'+NewFile+'" exists')
		if not os.path.exists(NewFile):
			Error (101644,'Input file "'+NewFile+'" not found')

		# check whether this is a placeholder file and read date and size from this
		file = open ( NewFile, 'rb' )
		Test = file.read(31)
		if Test == 'TRANSIMS RTE placeholder file!\n':
			NumPlaceHolders = 1
			FileName = file.readline().strip()
			ModTime = file.readline().strip()
			Size = file.readline().strip()
			Test = (MakeRelativePath(NewFile,ReferenceFile), ModTime, Size, 'INPUT')
			if var.SHOW_IO_FILES:
				Progress ('"'+self.Template+'" input file: "'+NewFile+'" (placeholder)')
		else:
			# in this case this is not a placeholder file but an actual input file
			NumPlaceHolders = 0
			Test = (MakeRelativePath(NewFile,ReferenceFile), str(os.path.getmtime(NewFile)), str(os.path.getsize(NewFile)), 'INPUT')
			if var.SHOW_IO_FILES:
				Progress ('"'+self.Template+'" input file: "'+NewFile+'" (exists)')
		return Test, NumPlaceHolders

	#--------------------------------------------------------
	def __IsPartitionFile (self, Key, Partitioned):
		"""
		This is an internal function to catch the rare case where
		a serial tool produces a partitioned file. Return True or False.
		"""

		# loop over the partition file rules
		if self.Template in ListOfPartFileRules:
			if Partitioned == False:
				if ListOfPartFileRules[self.Template]['partitioned'] == False:
					if Key in ListOfPartFileRules[self.Template]['keys']:
						return True
					else:
						return False
				return False
			else:
				if ListOfPartFileRules[self.Template]['partitioned'] == True:
					if Key in ListOfPartFileRules[self.Template]['keys']:
						return True
					else:
						return False
				return False
		else:
			return False

	#--------------------------------------------------------
	def GetOutputNetAsInputNet (self, PreviousNetwork=None):
		"""
		Retrieve the network keys of this object as a "Generic" object and
		replace the term "NEW_" at the beginning of each key with "NET_"
		so that the resulting keys can be used as network input keys for
		another control key object. If an optional "PreviousNetwork" parameter
		is given, it is copied to the output control key object before any
		of the current network keys are copied. This mechanism allows carrying
		forward a complex set of network keys without having to know the exact
		files currently being used.
		
		@note: Needs additional documentation!
		"""

		# create a generic control key object
		Result = ControlKeys()

		# copy from a previous network objects
		if PreviousNetwork != None:
			if self.__IsControlKeyObject(PreviousNetwork):
				Result.FromObject(PreviousNetwork, ReplaceKeys=True)
			else:
				Error(101688,'Previous network must be a control key object, not a "'+str(type(PreviousNetwork))+'" object')

		# copy or append the current network keys to the output object
		if 'NEW_DIRECTORY' in self.KeyArray:
			Key = 'NEW_DIRECTORY'
			Result.SetKey(Key.replace('NEW_','NET_'),self.KeyArray[Key], ReplaceKeys=True)
		for Key in self.KeyArray:
			if self.__IsOutputNetworkFile(Key):
				if Key.startswith('NEW_'):
					Result.SetKey(Key.replace('NEW_','NET_'),self.KeyArray[Key], ReplaceKeys=True)
		return Result

	#--------------------------------------------------------
	def __GetMatchingResultKey (self, Partition, String):
		"""
		Internal function that identifies the first matching result key.
		String contains a text fragment that is being matched against
		the result keys extracted from the PRN file.
		"""

		# the string is converted to upper case and blanks are converted to underscores
		String = String.upper().replace('-','_').replace(' ','_')

		# sort the result keys before trying to match with the string
		Keys = self.Results[Partition]['Variables'].keys()
		Keys.sort ()
		for Key in Keys:
			if Key.find (String) >= 0:
				return Key
		return None

	#--------------------------------------------------------
	def GetResult (self, Key, Partition=None, Default=None, Type='SUM'):
		"""
		Retrieve a result from a control key object after successful execution
		of a TRANSIMS tool. The key is an identifying fragment from the line
		in the PRN file that comes before the value. This fragment is matched
		against all lines from the PRN file to find a matching value. The value
		for a specific partition can be requested. If a value for all partitions
		is requested, the values are summed up by default. 'AVG', 'AVERAGE',
		'COUNT', 'AVG1', 'AVERAGE1', 'COUNT1', 'MIN', 'MAX', and 'TOTAL'
		are additional aggregation functions, in addition to 'SUM'. If the result
		key cannot be found, the value specified in "Default" is being returned.
		
		@note: Needs additional documentation!
		"""

		Type = Type.upper()
		# check the result type
		if Type not in ( 'AVG', 'AVERAGE', 'COUNT', 'AVG1', 'AVERAGE1', 'COUNT1', 'MIN', 'MAX', 'SUM', 'TOTAL' ):
			Error (102304,'The specified result type in the call to GetResult() is invalid')
		NumPartitions = len(self.Results)
		# for result type COUNT, return the number of partitions
		if Type == 'COUNT':
			return NumPartitions
		# check whether the user requested a simple result from a specific partition (base 0)
		if Partition == None:
			# the user did not request a result from a specific partition
			if NumPartitions == 1:
				# if there is only one partition, return the result. If there is no
				# matching result, return the specified default value. If the result
				# type is COUNT1, return 1 if a result exists and 0 if not.
				RealKey = self.__GetMatchingResultKey (0, Key)
				if RealKey != None:
					if Type == 'COUNT1':
						return 1
					else:
						return self.Results[0]['Variables'][RealKey]
				if Type == 'COUNT1':
					return 0
				else:
					return Default
			else:
				# otherwise, we loop over the partitions and aggregate the results.
				NumValuesFound = 0
				SumOfValues = 0
				MinValue = MaxValue = None
				for Partition in self.Results:
					RealKey = self.__GetMatchingResultKey (Partition, Key)
					if RealKey != None:
						NumValuesFound += 1
						if type(self.Results[Partition]['Variables'][RealKey]) not in (int,float):
							Error (101723,'Non-numerical values require GetResult() to be called for individual partitions only')
						Value = self.Results[Partition]['Variables'][RealKey]
					else:
						if Default == None:
							Default = 0
						if type(Default) not in (int,float):
							Error (102338,'A non-numerical default value for GetResult() is illegal when requesting an aggregate result type')
						Value = Default
					SumOfValues += Value
					if MinValue == None or Value < MinValue:
						MinValue = Value
					if MaxValue == None or Value > MaxValue:
						MaxValue = Value
				if Type == 'SUM' or Type == 'TOTAL':
					return SumOfValues
				elif Type == 'COUNT1':
					return NumValuesFound
				elif Type == 'MIN':
					return MinValue
				elif Type == 'MAX':
					return MaxValue
				elif Type == 'AVERAGE' or Type == 'AVG':
					return SumOfValues / NumPartitions
				elif Type == 'AVERAGE1' or Type == 'AVG1':
					if NumValuesFound > 0:
						return SumOfValues / NumValuesFound
					return 0
		else:
			# if a specific partition is specified ...
			if Partition in self.Results:
				RealKey = self.__GetMatchingResultKey (Partition, Key)
				if RealKey != None:
					if Type == 'COUNT1':
						return 1
					else:
						return self.Results[Partition]['Variables'][RealKey]
			if Type == 'COUNT1':
				return 0
			else:
				return Default

	#--------------------------------------------------------
	def __RunIfNeeded (self, Directory, Partitioned, NewCache, NewCacheTest, Protect, NewControlFile, Executable, NumPartitions=0, Partition=0, ForceExecution=False):
		"""
		This is an internal function that is being called for the
		execution of every instance of every tool to check whether
		it really needs to be executed. This involves checking of
		known input files, their dates and sizes, checking whether
		output files exist, dates of executables, and more. The
		tool is then only put into the work queue if needed. The function
		implements much of the caching capabilities of RTE. "PostProcessRun"
		implements the remainder.
		"""

		NumInputPlaceHolderFiles = 0
		PlaceholderFiles = []

		PartitionText = ''
		if Partitioned:
			PartitionText = ' (Partition ' + str (Partition) + ')'

		# Determine the name of the report file from a control file name (either by replacing
		# the extension or by analyzing the REPORT_FILE key). Report files will be analyzed
		# after execution to extract results, and are assembled differently in partitioned mode
		if Partitioned:
			ReportFile = self.__GetPrnFileName (NewControlFile, Partition)
		else:
			ReportFile = self.__GetPrnFileName (NewControlFile)

		# report the ctl and prn file to the GUI if requested
		if EmbedGuiHints:
			Lock.acquire()
			print '@GUI@ CTL','CONTROL_FILE -1',NewControlFile
			print '@GUI@ PRN','REPORT_FILE -1',ReportFile
			Lock.release()

		Message ('The new report file will be "' + str (ReportFile) + '"')

		# Unfortunately the semantics of partitions are not consistent accross the different
		# TRANSIMS tool. Some tools read partitions with the .t* specifier at the end
		# of the input file key.  They may write to single output files or partitioned output files.
		# Some tools have the syntax that they will create partitions on output if the .t*
		# key is appended to the output file key. For this specific case, we determine the number
		# of input partitions and use that as the number of output partitions, and issue a warning
		# if the numbers don't match (e.g repartitioning). 
		NumPartsOutput = 0

		# Determine all input files for this module and loop over them to see whether they exist
		# Network files are combined with the NET_DIRECTORY key. Other files
		# are combined with the PROJECT_DIRECTORY key. At this point they may
		# still be relative path names, so they are now combined with the working directory to
		# form an absolute path.  Input files must of course exist, otherwise an error
		# is being produced.
		for Key in self.__GetInputFileKeys ():

			# NULL as a value means that the key is not set, so this is not a file name
			if self.GetFinalKey (Key).upper() == 'NULL':
				continue

			# NOTE: The logic for the PROJECT_DIRECTORY needs to be checked
			if self.__IsNetworkFile (Key):
				NewDir = os.path.join (self.GetFinalKey ('NET_DIRECTORY',''), self.GetFinalKey (Key))
			else:
				NewDir = os.path.join (self.GetFinalKey ('PROJECT_DIRECTORY',''), self.GetFinalKey (Key))

			NewFile = os.path.abspath (os.path.join (Directory, NewDir)).replace ('\\','/')

			# Files are possibly partitioned and are read in sequence
			if NewFile.endswith ('.t*'):
				NumParts = 0
				while True:
					PartFile = GetPartitionFilename (NewFile[:-3], NumParts)
					if os.path.exists (PartFile):
						Result, NumPlaceHolders = self.__TestInputFile (Key, PartFile, NewControlFile)
						NumInputPlaceHolderFiles += NumPlaceHolders
						if NumPlaceHolders > 0:
							PlaceholderFiles.append(PartFile)
						NewCache['Marker'].append (Result)
						NewCacheTest.append (Result)
						if EmbedGuiHints:
							Lock.acquire()
							print '@GUI@ INP',Key,NumParts,PartFile
							Lock.release()
						NumParts += 1
					else:
						break
				Progress ( '"' + self.Template + '" input file "' + NewFile + '" consists of ' + str (NumParts) + ' partitions' )
				# Set the number of output partitions to the number of input partitions
				# if it is not known yet.
				if NumPartsOutput == 0:
					NumPartsOutput = NumParts
				if NumPartsOutput != NumParts:
					Warning(100403,'Inconsistent partition counts in multiple input file keys')

			else:
				# For partitioned files, the file name may be even different from what's specified in the
				# control key. This is true for things like the household lists in the Router
				if Partitioned == True and self.__IsPartitionFile (Key, Partitioned):
					NewFile = GetPartitionFilename (NewFile, Partition)

				# Run a test and return a tuple to append to the cache objects (file size, date, name)
				Result, NumPlaceHolders = self.__TestInputFile (Key, NewFile, NewControlFile)
				NumInputPlaceHolderFiles += NumPlaceHolders
				if NumPlaceHolders > 0:
					PlaceholderFiles.append(NewFile)

				# Append the result to the cache objects for later comparison
				NewCache['Marker'].append (Result)
				NewCacheTest.append (Result)
				if EmbedGuiHints:
					Lock.acquire()
					print '@GUI@ INP',Key,-1,NewFile
					Lock.release()

		# Check output files. The file names are assembled the same way as for input files,
		# except for the use of the NEW_DIRECTORY key. The directory for the output
		# files may not exist and is being created if it doesn't.
		for Key in self.__GetOutputFileKeys ():

			# NULL as a value means that the key is not set, so this is not a file name
			if self.GetFinalKey (Key).upper() == 'NULL':
				continue

			# NOTE: The logic for the PROJECT_DIRECTORY needs to be checked
			if self.__IsNetworkFile (Key):
				NewDir = os.path.join (self.GetFinalKey ('NEW_DIRECTORY', ''), self.GetFinalKey (Key))
			else:
				NewDir = os.path.join (self.GetFinalKey ('PROJECT_DIRECTORY', ''), self.GetFinalKey (Key))

			NewFile = os.path.abspath (os.path.join (Directory, NewDir)).replace ('\\','/')

			# Files are possibly partitioned and are written in sequence, such as PlanSum in plan update mode
			if NewFile.endswith ('.t*'):
				for Num in range(NumPartsOutput):
					NewFileWithExt = GetPartitionFilename (NewFile[:-3], Num)
					NewCacheTest.append (self.__TestOutputFile (Key, NewFileWithExt, NewControlFile, Protect, Silent=False))

			else:
				# Even for non-partitioned files, the file name may be different from what's specified in the
				# control key. This is true for things like the household lists created in HHList. Loop over the
				# files to be created and include them all in the cache object
				if Partitioned == False and self.__IsPartitionFile (Key, Partitioned):
					for Num in range (var.NUM_PARTITIONS):
						NewFileWithExt = GetPartitionFilename (NewFile, Num)
						NewCacheTest.append (self.__TestOutputFile (Key, NewFileWithExt, NewControlFile, Protect, Silent=False))

				# For partitioned files, the file name may need to be appended with the partition information,
				# similar to the input file processing above
				elif Partitioned == True and self.__IsPartitionFile (Key, Partitioned):
					NewFileWithExt = GetPartitionFilename (NewFile, Partition)
					NewCacheTest.append (self.__TestOutputFile (Key, NewFileWithExt, NewControlFile, Protect, Silent=False))

				# Otherwise, no extension is being appended (this is the most common case)
				else:
					NewCacheTest.append (self.__TestOutputFile (Key, NewFile, NewControlFile, Protect, Silent=False))

		# In dry run mode, we don't execute the TRANSIMS module but create missing output
		# files as dummies.
		if var.DRY_RUN == True:

			# Loop over the output files and create placeholders files
			for Key in self.__GetOutputFileKeys ():

				# NULL as a value means that the key is not set, so this is not a file name
				if self.GetFinalKey (Key).upper() == 'NULL':
					continue

				# NOTE: The logic for the PROJECT_DIRECTORY needs to be checked
				if self.__IsNetworkFile (Key):
					NewDir = os.path.join (self.GetFinalKey ('NEW_DIRECTORY', ''), self.GetFinalKey (Key))
				else:
					NewDir = os.path.join (self.GetFinalKey ('PROJECT_DIRECTORY', ''), self.GetFinalKey (Key))

				NewFile = os.path.abspath (os.path.join (Directory, NewDir)).replace ('\\','/')

				# Even for non-partitioned files, the file name may be different from what's specified in the
				# control key. This is true for things like the household lists created in HHList. Loop over the
				# files to be created and include them all in the cache object
				if Partitioned == False and self.__IsPartitionFile (Key, Partitioned):
					for Num in range (var.NUM_PARTITIONS):
						NewFileWithExt = GetPartitionFilename (NewFile, Num)
						CreateDryRunFileIfNeeded (NewFileWithExt)

				# For partitioned files, the file name may need to be appended with the partition information,
				# similar to the input file processing above
				elif Partitioned == True and self.__IsPartitionFile (Key, Partitioned):
					NewFileWithExt = GetPartitionFilename (NewFile, Partition)
					CreateDryRunFileIfNeeded (NewFileWithExt)

				# Otherwise, no extension is being appended (this is the most common case)
				else:
					CreateDryRunFileIfNeeded (NewFile)

			# Inform the user and return to the calling function
			Progress ('Dry Run Mode: Skipping execution of "' + self.Template + PartitionText + '"')
			return NumInputPlaceHolderFiles

		# Check the cache to see if this module needs to be executed
		NeedsToRun = True
		CachedExitCode = None
		if Partitioned:
			CacheFile = os.path.splitext (NewControlFile)[0] + '_' + str (Partition) + '.cache'
		else:
			CacheFile = os.path.splitext (NewControlFile)[0] + '.cache'

		# Run through the cache file and see why we need to run the tool. That allows us to
		# tell the usrer and to deal with the place holder file logic.
		CacheReason = []
		CacheReason.append('Caching is turned off!')
		if var.USE_CACHE:
			CacheReason = []
			if os.path.exists (CacheFile):
				try:
					PrevCache = LoadCacheFromFile(CacheFile)
					if PrevCache == None:
						Error ( 100527,'Missing or invalid cache file: "'+str(CacheFile)+'"!' )

					NeedsToRun = False
					CachedExitCode = PrevCache['Data']['ExitCode']

					CacheFileDir = os.path.split(CacheFile)[0]
					CacheFileDir = os.path.normpath(CacheFileDir).replace('\\','/')

					Prev = {}
					for Entry in PrevCache['Marker']:
						Prev[Entry[0]] = (Entry[1],Entry[2])
					Curr = {}
					for Entry in NewCacheTest:
						Curr[Entry[0]] = (Entry[1],Entry[2])

					# Go through the entries and see whether matching entries
					# are available in the current cache dictionary
					for Key in Prev.keys():
						AbsFilename = MakeAbsolutePath(Key,CacheFile)
						if Key not in Curr:
							NeedsToRun = True
							CacheReason.append('File '+AbsFilename+': file doesn\'t exist in cache file!')
						else:
							if Curr[Key] != Prev[Key]:
								NeedsToRun = True
								if os.path.exists(AbsFilename):
									if Curr[Key][0] != Prev[Key][0]:
										CacheReason.append('File '+AbsFilename+': file time stamps don\'t match!')
									elif Curr[Key][1] != Prev[Key][1]:
										CacheReason.append('File '+AbsFilename+': file size doesn\'t match!')
									else:
										CacheReason.append('File '+AbsFilename+': unidentified match problem!')
								else:
									CacheReason.append('File '+AbsFilename+': file doesn\'t exist yet!')
					# Reverse this search and see whether matching entries
					# are available in the previous cache dictionary
					for Key in Curr.keys():
						AbsFilename = MakeAbsolutePath(Key,CacheFile)
						if Key not in Prev:
							NeedsToRun = True
							CacheReason.append('File '+AbsFilename+': file not found in existing cache!')
						else:
							if Curr[Key] != Prev[Key]:
								NeedsToRun = True
								if os.path.exists(AbsFilename):
									if Curr[Key][0] != Prev[Key][0]:
										CacheReason.append('File '+AbsFilename+': file time stamps don\'t match!')
									elif Curr[Key][1] != Prev[Key][1]:
										CacheReason.append('File '+AbsFilename+': file size doesn\'t match!')
									else:
										CacheReason.append('File '+AbsFilename+': unidentified match problem!')
								else:
									CacheReason.append('File '+AbsFilename+': file doesn\'t exist yet!')
				except:
					NeedsToRun = True
					CacheReason.append('Exception while testing cache!')
			else:
				CacheReason.append('No cache file present!')

		if var.SKIP_EXECUTION:
			if NeedsToRun:
				Warning(100586,'The cache test failed and the tool should actually be executed. Inconsistent results and crashes are expected if the run continues. The continuation of the run under these conditions has been explicitly requested by the user, probably while developing this model. Consider revising the script and turning skip execution mode off.')
				CachedExitCode = 2
			NeedsToRun = False

		# if the parameter ForceExecution=True was given in the Run() command,
		# we force execution no matter what any of the var.USE_CACHE or 
		# var.SKIP_EXECUTION variables instruct us to do otherwsise.
		if ForceExecution == True:
			if NeedsToRun:
				Progress ( 'The "ForceExecution=True" option is in effect although the cache check or the skip execution flag determined that execution is not absolutely required. As a result, we are going to execute this tool as instructed. If it creates outpur file that are input files required by subsequent tools, they will run as well, triggered by the missed cache algorithm unless the skip execution flag is specified.' )
			NeedsToRun = True

		# Some of the data available to this function needs to available to the postprocessing
		# function as well (before multi-core processing, this was a single function). The way
		# we do this is by packaging the data into a list which itself becomes part of a list of
		# data sent to the WorkQueue. The worker thread returns the packaged list unchanged
		# upon finishing a run of an executable so that the same data is available to the
		# postprocessing function. It's a bit complicated, but works just fine.
		PassThroughData = (Partitioned, Directory, Partition, ReportFile, NewCache, CacheFile, Protect, CachedExitCode, NumPartsOutput)

		# Execute the tool
		if NeedsToRun:
			CacheReason.sort()
			LastReason = ''
			for Reason in CacheReason:
				if Reason != LastReason:
					if var.EXPLAIN_CACHE == True:
						Progress ('Reason for execution: '+Reason)
					LastReason = Reason
			if ForceExecution:
				Progress ('The "ForceExecution=True" option is in effect! The cache will be ignored, and the tool will be executed!')
			if NumInputPlaceHolderFiles > 0:
				CleanupPlaceholders(CacheFile, PlaceholderFiles)
				Error ( 100618,'IMPORTANT: PLEASE RESTART YOUR MODEL. The execution of this tool depends on files that have been previously replaced with placeholder files (see the ReplaceFilesWithPlaceholders() function call in your script). An automatic analysis of your file dependencies has been performed to determine an appropriate restart point. A number of placeholder files has been deleted as shown in the above messages. This action should get your model into a state where it can resume successfully from an earlier point in time where original files are available. Rerunning the script should now resume actual execution from a point where the caching mechanism can successfully operate by recreating files that had been replaced with placeholder files.' )
			Progress ('Executing "' + self.Template + PartitionText + '" with options "' + str (var.OPTIONS) + '"')
			if Partitioned:
				WorkQueue.put ([PassThroughData, Executable, NewControlFile, Partition, True])
			else:
				WorkQueue.put ([PassThroughData, Executable, NewControlFile, None, True])
		else:
			if var.SKIP_EXECUTION:
				Progress ('Executing "' + self.Template + PartitionText + '" with options "' + str (var.OPTIONS) + '" (skipped)')
			elif var.USE_CACHE:
				Progress ('Executing "' + self.Template + PartitionText + '" with options "' + str (var.OPTIONS) + '" (cached)')
			WorkQueue.put ([PassThroughData, Executable, NewControlFile, None, False])

		return NumInputPlaceHolderFiles




	#--------------------------------------------------------
	def __PostProcessRun (self, ExitCode, Buffer, PerformanceData, Partitioned, Directory, Partition, ReportFile, NewCache, CacheFile, Protect, NumPartsOutput):
		"""
		This is an internal function that is executed after the control
		key object has received the result of an execution back from the
		result queue. It is a counterpart to RunIfNeeded - it finalizes
		the cache information from the actual results of a run, so that
		RunIfNeeded has a basis to decide whether any files are outdated.
		"""

		PartitionText = ''
		if Partitioned:
			PartitionText = ' (Partition ' + str (Partition) + ')'

		# Create the results dictionary for later use
		self.Results[Partition] = ExtractResults(ReportFile)
		self.Results[Partition]['ExitCode'] = ExitCode

		# Display summary and detailed warning information to the user if there is any
		NumWarnings = len (self.Results[Partition]['Warnings'])
		List = self.Results[Partition]['WarningTypes'].keys()
		if len(List) > 0:
			List.sort ()
			Progress ('>>> WARNINGS: ' + str (NumWarnings) + ' (' + str (len (List)) + ' distinct types) in "' + self.Template + PartitionText + '" <<<')
			Counter = 1
			for Entry in List:
				Progress('>>> ' + str (Counter) + '.) "' + Entry + '" (*'+str (self.Results[Partition]['WarningTypes'][Entry]) + ')')
				Counter += 1
			Message ('>>> WARNINGS: Complete list of warning messages from "' + self.Template + PartitionText + '" <<<')
			Counter = 1
			for Entry in self.Results[Partition]['Warnings']:
				Message ('>>> ' + str (Counter) + '.) "' + Entry + '"')
				Counter += 1

		# Decode exit codes from the module
		if ExitCode == 0:
			Code = '(OK)'
		elif ExitCode == 1:
			Code = '(ERROR)'
		elif ExitCode == 2:
			Code = '(WARNING)'
		else:
			Code = '(UNKNOWN)'

		# Display detailed error information to the user
		if ExitCode == 1:
			Progress (' ')
			Progress ('>>> Final ' + str (var.TRACEBACK_LINES) + ' lines of output from "' + self.Template + PartitionText + '" <<<')
			for Line in Buffer:
				Progress (Line, Mark = ' |')
			Progress ('>>> End of output from "' + self.Template + PartitionText + '" <<<')
			Progress (' ')

		Progress ('"' + self.Template + PartitionText + '" finished with exit status ' + str (ExitCode) + ' ' + Code)

		# Terminate execution of the script if a fatal error occured
		if ExitCode == 1:
			Error (100682,'"' + self.Template + PartitionText + '" exited with a fatal error')
		if ExitCode not in (0,1,2):
			Error (100684,'"' + self.Template + PartitionText + '" exited with exit code ' + str (ExitCode))

		# Write the cache data file so that future runs of the script
		# can determine whether the output files need to be recreated
		for Key in self.__GetOutputFileKeys ():

			# NULL as a value means that the key is not set, so this is not a file name
			if self.GetFinalKey (Key).upper() == 'NULL':
				continue

			# NOTE: The logic for the PROJECT_DIRECTORY needs to be checked
			if self.__IsNetworkFile (Key):
				NewDir = os.path.join (self.GetFinalKey ('NEW_DIRECTORY', ''), self.GetFinalKey (Key))
			else:
				NewDir = os.path.join (self.GetFinalKey ('PROJECT_DIRECTORY', ''), self.GetFinalKey (Key))

			NewFile = os.path.abspath (os.path.join (Directory, NewDir)).replace ('\\', '/')

			# Even for non-partitioned files, the file name may be different from what's specified in the
			# control key. This is true for things like the household lists created in HHList. Loop over the
			# files to be created and include them all in the cache object
			if Partitioned == False and self.__IsPartitionFile (Key, Partitioned):
				for Num in range (var.NUM_PARTITIONS):
					NewFileWithExt = GetPartitionFilename (NewFile, Num)
					if os.path.exists (NewFileWithExt):
						NewCache['Marker'].append (self.__TestOutputFile (Key, NewFileWithExt, CacheFile, Protect))
						if EmbedGuiHints:
							Lock.acquire()
							print '@GUI@ OUT',Key,Num,NewFileWithExt
							Lock.release()
					else:
						Error (100715,'"' + NewFileWithExt + '" should have been created by "' + self.Template + PartitionText + '"')

			# For partitioned files, the file name may need to be appended with the partition information,
			# similar to the input file processing above
			elif Partitioned == True and self.__IsPartitionFile (Key, Partitioned):
				NewFileWithExt = GetPartitionFilename (NewFile, Partition)
				if os.path.exists (NewFileWithExt):
					NewCache['Marker'].append (self.__TestOutputFile (Key, NewFileWithExt, CacheFile, Protect))
					if EmbedGuiHints:
						Lock.acquire()
						print '@GUI@ OUT',Key,Partition,NewFileWithExt
						Lock.release()
				else:
					Error (100728,'"' + NewFileWithExt + '" should have been created by "' + self.Template + PartitionText + '"')

			# Otherwise, no automatic extension is being appended (this is the most common case)
			else:
				# but there may a .t* extension specified, and then we have to use the NumPartsOutput
				# method because we have no perfect understanding of how many partitions are being processed
				if NewFile.endswith('.t*') and NumPartsOutput > 0:
					for Num in range(NumPartsOutput):
						NewFileWithExt = GetPartitionFilename (NewFile[:-3], Num)
						if os.path.exists (NewFileWithExt):
							NewCache['Marker'].append (self.__TestOutputFile (Key, NewFileWithExt, CacheFile, Protect))
							if EmbedGuiHints:
								Lock.acquire()
								print '@GUI@ OUT',Key,Num,NewFileWithExt
								Lock.release()
						else:
							Error (100738,'"' + NewFileWithExt + '" should have been created by "' + self.Template + PartitionText + '"')
				else:
					# this is the simple case of a simple file with no special treatment
					if os.path.exists (NewFile):
						NewCache['Marker'].append (self.__TestOutputFile (Key, NewFile, CacheFile, Protect))
						if EmbedGuiHints:
							Lock.acquire()
							print '@GUI@ OUT',Key,Partition,NewFile
							Lock.release()
					else:
						Error (100739,'"' + NewFile + '" should have been created by "' + self.Template + PartitionText + '"')

		# Write the cache data to a file for future comparison and use.
		# If PerformanceData is None, then we have used the cache file, so we
		# should not rewrite it.
		if PerformanceData != None:
			NewCache['Data']['ExitCode'] = ExitCode
			NewCache['Data']['Directory'] = Directory
			NewCache['Data']['Partition'] = Partition
			NewCache['Data']['ReportFile'] = ReportFile
			NewCache['Data']['Version'] = RTE_Version + '.' + str (RTE_Revision) + ' (' + RTE_Author + ') on ' + RTE_Date
			NewCache['Data']['Keys'] = self.GetCtl()
			for Entry in PerformanceData:
				NewCache['Data'][Entry] = PerformanceData[Entry]
			NewCache['Results'] = self.Results[Partition]
			PickledCache = pickle.dumps (NewCache)
			File = open (CacheFile, 'wb')
			File.write (PickledCache)
			File.close ()

		return NumWarnings


		

#=========================================================================================================================
class ReplacementVariables:
	"""
	This class implements the "var" object. This is an object
	where all declared variables are used as templates when
	retrieving the value of a control key.
		
	@note: Needs additional documentation!
	"""
	#--------------------------------------------------------
	def __init__(self):
		pass
	#--------------------------------------------------------
	def Get(self,Name):
		if Name in vars(self):
			return vars(self)[Name]
		else:
			return None
	#--------------------------------------------------------
	def List(self):
		List = vars(self).keys()
		List.sort()
		return List
	#--------------------------------------------------------
# define is a single instance of this class - variables can be declared by the user within
# this object, and they will be automatically used as template variables.
var = ReplacementVariables()
"""
The var object is a special object in the user's name space
with a number of predefined variables, such as var.USE_CACHE.
Additional variables can be declared simply by the user in form of an
assignment, such as

var.MYVAL = 56

When expanding templates in control key files, strings, and arguments
to other RTE functions, all upper case variables in the var object are
used in the replacement process. For example, the template @MYVAL@ would
be replaced with the value 56 if that is the current value of the var.MYVAL
variable at time of expansion.
"""



#=========================================================================================================================
def ExpandTemplate(String):
	"""
	This function returns the string passed in the argument String
	after replacing all templates (words enclosed in a pair of @ signs)
	with corresponding variables from the var object.
		
		@note: Needs additional documentation!
	"""
	global var
	if type(String) != str:
		Error (102273,'The argument to the ExpandTemplate() function must be a string!')
	for Variable in var.List():
		String = String.replace("@"+Variable+"@",str(var.Get(Variable)))
	return String




# Open the performance file - append to it if it exists
PerformanceFileName = os.path.splitext(sys.argv[0])[0]+'.pfm'
PerformanceFile = open (PerformanceFileName,'wb')

# initializations
PrevCpuInfo = None
PrevNetInfo = None
CurrentTool = 'None'
StartTime = time.time()




#=========================================================================================================================
def CreateStats (Tool = None, Start = True):
	"""
	This is a function that runs continuously to collect CPU and memory statistics
	"""

	global PrevCpuInfo, PrevNetInfo, CurrentTool
	if Tool != None and Start == True:
		CurrentTool = Tool
	CpuInfo = {}
	NetInfo = {}
	for Node in Nodes:
		Command = 'ssh '+Node+' cat /proc/loadavg; echo @; cat /proc/meminfo | grep Mem; echo @; cat /proc/stat | grep cpu; echo @; /sbin/ifconfig eth0 | grep RX | grep bytes'
		Stack = shlex.split(Command)
		Output = subprocess.Popen(Stack, stdout=subprocess.PIPE).communicate()[0]
		Block = Output.split('@')
		LoadAvg = Block[0].strip().replace('/',' ').split()
		LoadAvg1m = LoadAvg[0]
		LoadAvg5m = LoadAvg[1]
		LoadAvg10m = LoadAvg[2]
		MemInfo = Block[1].strip().split()
		MemTotal = int(MemInfo[1])
		MemFree = int(MemInfo[4])
		MemUsed = MemTotal - MemFree
		Stat = Block[2].strip().split('\n')
		CpuInfo[Node] = {}
		CpuPercent = 0.0
		for Entry in Stat:
			Fields = Entry.split()
			Key = Fields[0]
			Fields.pop(0)
			CpuInfo[Node][Key] = Fields
		if PrevCpuInfo != None:
			List = CpuInfo[Node].keys()
			List.sort()
			for Entry in List:
				CPU = []
				for i in range(len(CpuInfo[Node][Entry])):
					CPU.append(int(CpuInfo[Node][Entry][i]) - int(PrevCpuInfo[Node][Entry][i]),)
				break # consider just the total line, not the individual cpus
			CpuPercent = round( 100.0 * ( 1.0 - ( 1.0 * CPU[3] ) / ( CPU[0] + CPU[1] + CPU[2] + CPU[3] + CPU[4] + CPU[5] + CPU[6] ) ), 1)
		Net = Block[3].strip().split(':')
		NetInfo[Node] = []
		NetInfo[Node].append(int(Net[1].strip().split()[0]))
		NetInfo[Node].append(int(Net[2].strip().split()[0]))
		NetData = []
		if PrevNetInfo != None:
			for i in range(len(NetInfo[Node])):
				NetData.append(int(NetInfo[Node][i]) - int(PrevNetInfo[Node][i]))
			NetRX = NetData[0]
			NetTX = NetData[1]
			PerformanceFile.write(str(time.time()-StartTime)+','+Node+','+str(CurrentTool)+','+str(LoadAvg1m)+','+str(LoadAvg5m)+','+str(LoadAvg10m)+','+str(MemTotal)+','+str(MemUsed)+','+str(MemFree)+','+str(NetRX)+','+str(NetTX)+','+str(CpuPercent)+'\n')
			PerformanceFile.flush()
	PrevNetInfo = copy.deepcopy(NetInfo)
	PrevCpuInfo = copy.deepcopy(CpuInfo)
	if Start == False:
		CurrentTool = 'None'




#=========================================================================================================================
class NodePerformanceThread ( threading.Thread ):
	"""
	This is the thread that runs CreateStats.
	"""
	#--------------------------------------------------------
	def __init__(self, Nodes):
		self.Nodes = Nodes
		threading.Thread.__init__(self)
		return
	#--------------------------------------------------------
	def run(self):
		while True:
			CreateStats()
			time.sleep (10)
	#--------------------------------------------------------




#
# Information about all the possible variables for the runtime environment
#
var.BINDIR = None
var.WORKDIR = '.'
var.OPTIONS = '-B -K'
var.REPLACE_KEYS = False
var.OS = os.name
var.TRACEBACK_LINES = 30
var.USE_CACHE = True
var.EXPLAIN_CACHE = False
var.DRY_RUN = False
var.SKIP_EXECUTION = False
#
var.SHOW_MODULE_OUTPUT = 'PROGRESS'
ModuleOutputOptions = ('ALL', 'PROGRESS', 'DOTS', 'NONE' )
var.SHOW_LINE_NUMBERS = True
var.SHOW_RTE_LINE_NUMBERS = False
var.SHOW_IO_FILES = False
var.FILTER_INTERVAL = 10.0
var.OUTPUT_WIDTH = 0
var.DEBUG = False
var.QUIET = False

# determine the number of cores and similar
NumCores = GetNumberOfCPUs()
NodeFile = os.getenv('PBS_NODEFILE')
NumCoresPerNode = {}
PerformanceThread = None
if NodeFile != None:
	File = open (NodeFile, 'r')
	NumCores = 0
	for Line in File:
		Entry = Line.strip()
		NumCores += 1
		if Entry in NumCoresPerNode:
			NumCoresPerNode[Entry] += 1
		else:
			NumCoresPerNode[Entry] =1
	File.close ()
	NumNodes = len(NumCoresPerNode)
	Nodes = NumCoresPerNode.keys()
	Nodes.sort()
	PerformanceThread = NodePerformanceThread (Nodes)
	PerformanceThread.setDaemon (True)
	PerformanceThread.start ()
else:
	NumNodes = 1
	NumCoresPerNode['localhost'] = NumCores

var.NUM_PARTITIONS = NumCores
#
WorkQueue = Queue.Queue(0)
ResultQueue = Queue.Queue(0)
ArrayOfWorkerThreads = {}
#
Lock = threading.Lock()

#
# Progress messages
#
JobStartTime = time.time()
IsShowingDots = False
DotPosition = 0
PrevElapsedTime = 0.0
PreviousLine = 0
#

#
# determine the directory where the TransimsRTE module is installed.
# This becomes especially important for distributions where we have
# no idea where TransimsRTE will be in fact placed. A trick is to
# have an empty python file parallel to __init__.py in the
# package, called empty.py.  The inspect module allows us to find
# the path to such a module after importing it, and now we have
# knowledge about the directory where we should look for data
# files. Very clumsy, but it works.
import inspect
import empty
Directory = os.path.dirname(inspect.getsourcefile(empty))

#
# Import the information about control keys for all TRANSIMS tools
#
ListOfMetaData = None
if os.path.exists(os.path.join(Directory,'rules/TransimsRTE.lmd')):
	file = open(os.path.join(Directory,'rules/TransimsRTE.lmd'),'rb')
	ListOfMetaData = pickle.load(file)
	file.close()
ListOfKeys = None
if os.path.exists(os.path.join(Directory,'rules/TransimsRTE.lmk')):
	file = open(os.path.join(Directory,'rules/TransimsRTE.lmk'),'rb')
	ListOfKeys = pickle.load(file)
	file.close()
if ListOfMetaData == None:
	Error (101923,'Unable to load the pickled meta data file!')
if ListOfKeys == None:
	Error (101925,'Unable to load the pickled key definition file!')

# determine which keys read or write partitioned files
# for each of the partitionable tools
ListOfPartFileRules = None
if os.path.exists(os.path.join(Directory,'rules/TransimsRTE.pfr')):
	file = open(os.path.join(Directory,'rules/TransimsRTE.pfr'),'rt')
	ListOfPartFileRules = {}
	for line in file:
		line = line.strip()
		fields = line.split(',')
		ListOfPartFileRules[fields[1]] = {}
		if fields[0].upper() == 'TRUE':
			ListOfPartFileRules[fields[1]]['partitioned'] = True
		else:
			ListOfPartFileRules[fields[1]]['partitioned'] = False
		ListOfPartFileRules[fields[1]]['keys'] = []
		for i in range(len(fields)-2):
			ListOfPartFileRules[fields[1]]['keys'].append(fields[2+i])
	file.close()

# Open the log file
LogFileName = os.path.splitext(sys.argv[0])[0]+'.log'
if LogFileName == sys.argv[0]:
	Error (101949,'Script is trying to overwrite itself with a log file!')
LogFile = open(LogFileName,'wt')

# check for some special options related to the GUI
EmbedGuiHints = False
if '--embed-gui-hints' in sys.argv:
	EmbedGuiHints = True
IgnorePidFile = False
if '--ignore-pid-file' in sys.argv:
	IgnorePidFile = True
if '--transims-bin-dir' in sys.argv:
	Index = sys.argv.index('--transims-bin-dir')
	if Index < len(sys.argv)-1:
		var.BINDIR = sys.argv[Index+1]

# Lock the process using a PID file so that no two instances can
# run at the same time, overwriting each other's files
PidFileName = os.path.splitext(sys.argv[0])[0]+'.pid'
ProcessLock = LockPID ( PidFileName )

# Create the cache file tracker list. This list stores information about
# the invocation of each control key object in sequence, and in particular the names of
# the cache files used and created by each run. When placeholder files cause
# trouble, this hierarchy can be traversed to analyze dependencies and determine
# which placedholder files should be deleted to allow for a clean and successful
# restart.
CacheFileTracker = []

#
# Create the global control keys object
#
GlobalKeys = ControlKeys('GlobalControlKeys')
"""
This is the global control key object, holding all keys that
are common to all tools.

@note: Needs additional documentation!
"""
# --- the end ---
